<?php
/**
 * Customize for Shop loop product
 */
return [
    [
        'type' => 'section',
        'name' => 'zoo_contact',
        'title' => esc_html__('Contact', 'kodo'),
    ],
    [
        'name' => 'zoo_contact_general_settings',
        'type' => 'heading',
        'label' => esc_html__('Contact Settings', 'kodo'),
        'section' => 'zoo_contact',
    ],
    [
        'name' => 'zoo_contact_type',
        'type' => 'select',
        'section' => 'zoo_contact',
        'title' => esc_html__('Contact Type', 'kodo'),
        'default' => 'none',
        'choices' => [
            'none' => esc_html__('None', 'kodo'),
            'phone' => esc_html__('Phone', 'kodo'),
            'email' => esc_html__('Email', 'kodo'),
            'messenger' => esc_html__('Messenger', 'kodo'),
            'whatsapp' => esc_html__('Whatsapp', 'kodo'),
            'skype' => esc_html__('Skype', 'kodo'),
        ]
    ],
    [
        'type' => 'text',
        'name' => 'zoo_contact_id',
        'label' => esc_html__('Contact ID', 'kodo'),
        'section' => 'zoo_contact',
        'description' => esc_html__('Your contact id. That is your phone, email or social id follow type contact you selected', 'kodo'),
        'required' => ['zoo_contact_type', '!=', 'none'],
    ],[
        'type'    => 'select',
        'name' => 'zoo_contact_pos',
        'label' => esc_html__('Contact Position', 'kodo'),
        'section' => 'zoo_contact',
        'description' => esc_html__('', 'kodo'),
        'default' => 'left',
        'choices' => [
            'left' => esc_html__('Left', 'kodo'),
            'right' => esc_html__('Right', 'kodo'),
        ],
        'required' => ['zoo_contact_type', '!=', 'none'],
    ],
    [
        'name' => 'zoo_contact_size',
        'type' => 'slider',
        'section' => 'zoo_contact',
        'min' => 0,
        'step' => 1,
        'max' => 300,
        'required' => ['zoo_contact_type', '!=', 'none'],
        'selector'  => '.zoo-contact-button>.zoo-contact-link',
        'css_format' => 'width: {{value}};height: {{value}}',
    ],[
        'name' => 'zoo_contact_font_size',
        'type' => 'slider',
        'section' => 'zoo_contact',
        'min' => 0,
        'step' => 1,
        'max' => 100,
        'required' => ['zoo_contact_type', '!=', 'none'],
        'selector'  => '.zoo-contact-button>.zoo-contact-link',
        'css_format' => 'font-size: {{value}}',
    ],
    [
        'name' => 'zoo_contact_color',
        'type' => 'color',
        'section' => 'zoo_contact',
        'title' => esc_html__('Color', 'kodo'),
        'selector' => '.zoo-contact-button>.zoo-contact-link',
        'css_format' => 'color: {{value}};',
        'required' => ['zoo_contact_type', '!=', 'none'],
    ],[
        'name' => 'zoo_contact_bg_color',
        'type' => 'color',
        'section' => 'zoo_contact',
        'title' => esc_html__('Background Color', 'kodo'),
        'selector' => '.zoo-contact-button>.zoo-contact-link',
        'css_format' => 'background-color: {{value}};',
        'required' => ['zoo_contact_type', '!=', 'none'],
    ],
];
