<?php
/**
 * Customize for Site
 */
return [
    [
        'name' => 'zoo_general',
        'type' => 'section',
        'label' => esc_html__('General', 'kodo'),
        'priority'=>0
    ],
    [
        'name' => 'zoo_site_layout',
        'type' => 'select',
        'section' => 'zoo_general',
        'title' => esc_html__('Site Layout', 'kodo'),
        'description' => esc_html__('Config Layout for site', 'kodo'),
        'default' => 'normal',
        'choices' => [
            'normal' => esc_html__('Normal', 'kodo'),
            'boxed' => esc_html__('Boxed', 'kodo'),
            'full-width' => esc_html__('Full Width', 'kodo'),
        ]
    ],[
        'name' => 'zoo_site_max_width',
        'type' => 'number',
        'section' => 'zoo_general',
        'title' => esc_html__('Site Max Width', 'kodo'),
        'description' => esc_html__('Max width content of site. Leave it blank or 0, size max width will full width.', 'kodo'),
        'default' => '1400',
    ],[
        'name' => 'zoo_disable_breadcrumbs',
        'type' => 'checkbox',
        'section' => 'zoo_general',
        'title' => esc_html__('Disable Breadcrumbs', 'kodo'),
        'default' => 0,
        'checkbox_label' => esc_html__('Breadcrumbs will remove if checked.', 'kodo'),
    ],[
        'name' => 'zoo_disable_emojis',
        'type' => 'checkbox',
        'section' => 'zoo_general',
        'title' => esc_html__('Disable Emojis', 'kodo'),
        'default' => 1,
        'checkbox_label' => esc_html__('Emojis will remove if checked.', 'kodo'),
    ],[
        'name' => 'zoo_enable_lazy_image',
        'type' => 'checkbox',
        'section' => 'zoo_general',
        'title' => esc_html__('Enable Lazy Load Images', 'kodo'),
        'default' => 1,
        'checkbox_label' => esc_html__('Enable Lazy Load Images if checked.', 'kodo'),
    ],[
        'name' => 'zoo_using_adaptive_image',
        'type' => 'checkbox',
        'section' => 'zoo_general',
        'title' => esc_html__('Using Adaptive Images', 'kodo'),
        'required' => ['zoo_enable_lazy_image', '==', 1],
        'default' => 1,
        'checkbox_label' => esc_html__('Using adaptive image for lazy load image. Disable if want use placeholder image for lazy load image.', 'kodo'),
    ],[
        'name' => 'zoo_enable_site_meta',
        'type' => 'checkbox',
        'section' => 'zoo_general',
        'title' => esc_html__('Enable Site Meta', 'kodo'),
        'default' => 0,
        'checkbox_label' => esc_html__('Show post thumbnail, title, description when share.', 'kodo'),
    ],[
        'name' => 'zoo_enable_back_top_top',
        'type' => 'checkbox',
        'section' => 'zoo_general',
        'title' => esc_html__('Enable Back to Top', 'kodo'),
        'default' => 1,
        'checkbox_label' => esc_html__('Show button back to top.', 'kodo'),
    ],
];