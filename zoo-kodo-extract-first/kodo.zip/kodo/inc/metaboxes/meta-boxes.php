<?php
/**
 * Meta box for theme
 *
 * @package     Zoo Theme
 * @version     1.0.0
 * @core        3.0.0
 * @author      Zootemplate
 * @link        https://www.zootemplate.com/
 * @copyright   Copyright (c) 2020 ZooTemplate
 */

if ( class_exists( 'RWMB_Loader' ) ):
	add_filter( 'rwmb_meta_boxes', 'zoo_meta_box_options' );
	if ( ! function_exists( 'zoo_meta_box_options' ) ) {
		function zoo_meta_box_options() {
			$zoo_prefix       = "zoo_";
			$zoo_meta_boxes   = array();
			$zoo_meta_boxes[] = array(
				'id'      => $zoo_prefix . 'single_post_heading',
				'title'   => esc_html__( 'Sidebar Config', 'kodo' ),
				'pages'   => array( 'post' ),
				'context' => 'side',
				'fields'  => array(
					array(
						'id'      => $zoo_prefix . "blog_single_sidebar_config",
						'type'    => 'select',
						'options' => array(
							'inherit' => esc_html__( 'Inherit', 'kodo' ),
							'left'    => esc_html__( 'Left', 'kodo' ),
							'right'   => esc_html__( 'Right', 'kodo' ),
							''    => esc_html__( 'None', 'kodo' ),
						),
						'std'     => 'inherit',
						'desc'    => esc_html__( 'Select sidebar layout you want set for this post.', 'kodo' )
					),
				)
			);
			//All page
			$zoo_meta_boxes[] = array(
				'id'      => $zoo_prefix . 'layout_single_heading',
				'title'   => esc_html__( 'Layout Single Product', 'kodo' ),
				'pages'   => array( 'product' ),
				'context' => 'advanced',
				'fields'  => array(
					array(
						'name'    => esc_html__( 'Layout Options', 'kodo' ),
						'id'      => $zoo_prefix . "single_product_layout",
						'type'    => 'select',
						'options' => array(
							'inherit'          => esc_html__( 'Inherit', 'kodo' ),
							'vertical-thumb'   => esc_html__( 'Product V1', 'kodo' ),
							'horizontal-thumb' => esc_html__( 'Product V2', 'kodo' ),
							'carousel'         => esc_html__( 'Product V3', 'kodo' ),
							'grid-thumb'       => esc_html__( 'Product V4', 'kodo' ),
							'sticky-1'         => esc_html__( 'Product V5', 'kodo' ),
							'sticky-2'         => esc_html__( 'Product V6', 'kodo' ),
							'sticky-3'         => esc_html__( 'Product V7', 'kodo' ),
							//'accordion'        => esc_html__( 'Product V7', 'kodo' ),
							'custom'           => esc_html__( 'Custom', 'kodo' ),
						),
						'std'     => 'inherit',
					),
					array(
						'name'    => esc_html__( 'Content Options', 'kodo' ),
						'id'      => $zoo_prefix . "single_product_content_layout",
						'type'    => 'select',
						'options' => array(
							'inherit'        => esc_html__( 'Inherit', 'kodo' ),
							'right_content'  => esc_html__( 'Right Content', 'kodo' ),
							'left_content'   => esc_html__( 'Left Content', 'kodo' ),
							'full_content'   => esc_html__( 'Full width Content', 'kodo' ),
							'sticky_content' => esc_html__( 'Sticky Content', 'kodo' ),
						),
						'std'     => 'inherit',
					),
					array(
						'name'    => esc_html__( 'Gallery Options', 'kodo' ),
						'id'      => $zoo_prefix . "product_gallery_layout",
						'type'    => 'select',
						'options' => array(
							'inherit'        => esc_html__( 'Inherit', 'kodo' ),
							'vertical-left'  => esc_html__( 'Vertical Left Thumb', 'kodo' ),
							'vertical-right' => esc_html__( 'Vertical Right Thumb', 'kodo' ),
							'horizontal'     => esc_html__( 'Horizontal', 'kodo' ),
							'slider'         => esc_html__( 'Slider', 'kodo' ),
							'grid'           => esc_html__( 'Grid', 'kodo' ),
							'sticky'         => esc_html__( 'Sticky', 'kodo' ),
						),
						'std'     => 'inherit',
					),
					array(
						'name'    => esc_html__( 'Gallery Columns', 'kodo' ),
						'id'      => $zoo_prefix . "product_gallery_columns",
						'type'    => 'select',
						'options' => array(
							'6' => esc_html__( '6', 'kodo' ),
							'5' => esc_html__( '5', 'kodo' ),
							'4' => esc_html__( '4', 'kodo' ),
							'3' => esc_html__( '3', 'kodo' ),
							'2' => esc_html__( '2', 'kodo' ),
							'1' => esc_html__( '1', 'kodo' ),
							'inherit' => esc_html__( 'Inherit', 'kodo' ),
						),
						'std'     => 'inherit',
					),
                    array(
						'name'    => esc_html__( 'Display tab inside summary', 'kodo' ),
						'id'      => $zoo_prefix . "add_tab_to_summary",
						'type'    => 'select',
						'options' => array(
							'no' => esc_html__( 'No', 'kodo' ),
							'true' => esc_html__( 'Yes', 'kodo' ),
							'inherit' => esc_html__( 'Inherit', 'kodo' ),
						),
						'std'     => 'inherit',
					),
				)
			);
			$zoo_meta_boxes[] = array(
				'id'      => $zoo_prefix . 'single_product_image_360_heading',
				'title'   => esc_html__( 'Product image 360 view', 'kodo' ),
				'pages'   => array( 'product' ),
				'context' => 'advanced',
				'fields'  => array(
					array(
						'id'   => $zoo_prefix . "single_product_image_360",
						'name' => esc_html__( 'Images', 'kodo' ),
						'type' => 'image_advanced',
						'desc' => esc_html__( 'Images for 360 degree view.', 'kodo' )
					),
				)
			);
			$zoo_meta_boxes[] = array(
				'id'      => $zoo_prefix . 'single_product_video_heading',
				'title'   => esc_html__( 'Product Video', 'kodo' ),
				'pages'   => array( 'product' ),
				'context' => 'side',
				'fields'  => array(
					array(
						'id'   => $zoo_prefix . "single_product_video",
						'type' => 'oembed',
						'desc' => esc_html__( 'Enter your embed video url.', 'kodo' )
					),
				)
			);
			$zoo_meta_boxes[] = array(
				'id'      => $zoo_prefix . 'single_product_new_heading',
				'title'   => esc_html__( 'Assign product is New', 'kodo' ),
				'pages'   => array( 'product' ),
				'context' => 'side',
				'fields'  => array(
					array(
						'id'   => $zoo_prefix . "single_product_new",
						'std'  => '0',
						'type' => 'checkbox',
						'desc' => esc_html__( 'Is New Product.', 'kodo' )
					),
				)
			);
			$zoo_meta_boxes[] = array(
				'id'      => 'title_meta_box',
				'title'   => esc_html__( 'Layout Options', 'kodo' ),
				'pages'   => array( 'page', 'post' ),
				'context' => 'advanced',
				'fields'  => array(
					array(
						'name' => esc_html__( 'Title & Breadcrumbs Options', 'kodo' ),
						'desc' => esc_html__( '', 'kodo' ),
						'id'   => $zoo_prefix . "heading_title",
						'type' => 'heading'
					),
					array(
						'name' => esc_html__( 'Disable Title', 'kodo' ),
						'desc' => esc_html__( '', 'kodo' ),
						'id'   => $zoo_prefix . "disable_title",
						'std'  => '0',
						'type' => 'checkbox'
					),
					array(
						'name' => esc_html__( 'Disable Breadcrumbs', 'kodo' ),
						'desc' => esc_html__( '', 'kodo' ),
						'id'   => $zoo_prefix . "disable_breadcrumbs",
						'std'  => '0',
						'type' => 'checkbox'
					),
					array(
						'name' => esc_html__( 'Page Layout', 'kodo' ),
						'desc' => esc_html__( '', 'kodo' ),
						'id'   => $zoo_prefix . "body_heading",
						'type' => 'heading'
					),
					array(
						'name'    => esc_html__( 'Layout Options', 'kodo' ),
						'id'      => $zoo_prefix . "site_layout",
						'type'    => 'select',
						'options' => array(
							'inherit'    => esc_html__( 'Inherit', 'kodo' ),
							'normal'     => esc_html__( 'Normal', 'kodo' ),
							'boxed'      => esc_html__( 'Boxed', 'kodo' ),
							'full-width' => esc_html__( 'Full Width', 'kodo' ),
						),
						'std'     => 'inherit',
					),
					array(
						'name' => esc_html__( 'Page Max Width', 'kodo' ),
						'desc' => esc_html__( 'Accept only number. If not set, it will follow customize config.', 'kodo' ),
						'id'   => $zoo_prefix . "site_max_width",
						'type' => 'number'
					),
				)
			);

			return $zoo_meta_boxes;
		}
	}
endif;