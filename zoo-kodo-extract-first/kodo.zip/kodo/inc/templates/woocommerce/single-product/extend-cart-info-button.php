<?php
/**
 * Product extend cart info template
 * @package     Zoo Theme
 * @version     3.0.0
 * @author      Zootemplate
 * @link        https://www.zootemplate.com/
 * @copyright   Copyright (c) 2018 ZooTemplate
 *
 */
if(class_exists('\Elementor\Plugin')) {
    if (\Elementor\Plugin::$instance->preview->is_preview_mode()) {
        return;
    }
}
if(class_exists('CleverAddons')):
    $size_page=get_theme_mod('zoo_single_product_cart_size_guide');
    $delivery_page=get_theme_mod('zoo_single_product_cart_delivery');
    $ask_page=get_theme_mod('zoo_single_product_cart_ask_product');
    if(defined('ICL_LANGUAGE_CODE')){
      $size_page = icl_object_id($size_page, 'page', false,ICL_LANGUAGE_CODE);
      $delivery_page = icl_object_id($delivery_page, 'page', false,ICL_LANGUAGE_CODE);
      $ask_page = icl_object_id($ask_page, 'page', false,ICL_LANGUAGE_CODE);

    }

    if($size_page || $delivery_page || $ask_page):
        ?>
        <ul class="zoo-extend-cart-info">
            <?php
            if($size_page){?>
                <li class="zoo-extend-cart-info-item size-guide-block">
                    <a href="#" title="<?php echo esc_attr(get_post($size_page)->post_title)?>"  data-target="size-guide-content">
                       <?php echo esc_html(get_the_title($size_page))?>
                   </a>
               </li>
           <?php }
           if($delivery_page){?>
            <li class="zoo-extend-cart-info-item delivery-return-block">
                <a href="#" title="<?php echo esc_attr(get_post($delivery_page)->post_title)?>" data-target="delivery-return-content">
                   <?php echo esc_html(get_the_title($delivery_page))?>

               </a>
           </li>
       <?php }
       if($ask_page){?>
        <li class="zoo-extend-cart-info-item ask-product-block">
            <a href="#" title="<?php echo esc_attr(get_post($ask_page)->post_title)?>"  data-target="ask-product-content">
               <?php echo esc_html(get_the_title($ask_page))?>
           </a>
       </li>
   <?php }
   ?>
</ul>
<?php endif; endif; ?>