<?php
/**
 * Product extend cart info template
 * @package     Zoo Theme
 * @version     3.0.0
 * @author      Zootemplate
 * @link        https://www.zootemplate.com/
 * @copyright   Copyright (c) 2018 ZooTemplate
 *
 */
if(class_exists('\Elementor\Plugin')) {
    if (\Elementor\Plugin::$instance->preview->is_preview_mode()) {
        return;
    }
}
$size = get_theme_mod( 'zoo_single_product_cart_size_guide' );
$delivery = get_theme_mod( 'zoo_single_product_cart_delivery' );
$ask = get_theme_mod( 'zoo_single_product_cart_ask_product' );

if(defined('ICL_LANGUAGE_CODE')){
    $size = icl_object_id($size, 'page', false,ICL_LANGUAGE_CODE);
    $delivery = icl_object_id($delivery, 'page', false,ICL_LANGUAGE_CODE);
    $ask = icl_object_id($ask, 'page', false,ICL_LANGUAGE_CODE);

}
$size_page = get_post( $size);
$delivery_page = get_post( $delivery );
$ask_page = get_post( $ask );
?>
<?php if( $size || $delivery || $ask ){ ?>
<div class="wrap-content-popup-page">
    <?php 
    if ( $size ) { ?>
        <div class="content-popup-page size-guide-content">
            <?php echo apply_filters('zoo_the_content', do_shortcode(wp_kses_post($size_page->post_content))); ?>
        </div>
    <?php }
    if ( $delivery ) {
        ?>
        <div class="content-popup-page delivery-return-content">
            <?php echo apply_filters('zoo_the_content', do_shortcode(wp_kses_post($delivery_page->post_content))); ?>
        </div>
    <?php }
    if ( $ask ) {
        ?>
        <div class="content-popup-page ask-product-content">
            <?php echo apply_filters('zoo_the_content', do_shortcode(wp_kses_post($ask_page->post_content))); ?>
        </div>
    <?php } ?>
    <span class="close-popup-page"><i class="cs-font clever-icon-close"></i></span>
</div>
<div class="close-zoo-extend-cart-info"></div>
<?php } ?>
