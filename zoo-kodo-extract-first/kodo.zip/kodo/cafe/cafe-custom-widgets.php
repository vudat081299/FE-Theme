<?php
/**
 * elementor-theme Custom widgets.
 * Custom widget control for widget of Cafe plugins.
 */

add_action( 'elementor/element/clever-posts/layout_settings/before_section_end', function( $element, $args ) {
    $element->add_control('disable_border', [
        'label' => esc_html__('Disable border', 'kodo'),
        'description' => esc_html__('', 'kodo'),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'return_value' => 'true',
        'default' => 'false',
    ]);
}, 10, 2 );
add_action( 'elementor/element/clever-services/layout_settings/before_section_end', function( $element, $args ) {
    $element->remove_control('style');
    $element->add_control('style', [
        'label' => esc_html__('Style', 'kodo'),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'default',
        'options' => [
            'default' => esc_html__('Default', 'kodo'),
            'boxed' => esc_html__('Boxed', 'kodo'),
            'inline' => esc_html__('Inline', 'kodo'),
        ],
        'description' => esc_html__('Style of service.', 'kodo'),
    ]);
    $element->add_responsive_control('height', [
        'label' => esc_html__('Min Height', 'kodo'),
        'type' => \Elementor\Controls_Manager::SLIDER,
        'size_units'    => ['px', 'vh'],
        'range' => [
            'px' => [
                'min' => 1,
                'max' => 2000,
            ],'vh' => [
                'min' => 1,
                'max' => 100,
            ],
        ],
        'selectors' => [
            '{{WRAPPER}} .cafe-services .cafe-wrap-service' => 'min-height: {{SIZE}}{{UNIT}};',
        ],
        'devices' => ['desktop', 'tablet', 'mobile'],
        'condition' => [
            'style' => 'inline'
        ],
    ]);
}, 10, 2 );