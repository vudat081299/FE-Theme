<?php
/**
 * Register custom theme mods from a theme
 */

return [
     0 => require ZOO_THEME_DIR.'inc/customize/options/general.php',
     1 => require ZOO_THEME_DIR.'inc/customize/options/blog-archive.php',
     2 => require ZOO_THEME_DIR.'inc/customize/options/blog-single.php',
     3 => require ZOO_THEME_DIR.'inc/customize/options/shop.php',
     4 => require ZOO_THEME_DIR.'inc/customize/options/product-page.php',
     5 => require ZOO_THEME_DIR.'inc/customize/options/wishlist.php',
     6 => require ZOO_THEME_DIR.'inc/customize/options/compare.php',
     7 => require ZOO_THEME_DIR.'inc/customize/options/general-style.php',
     8 => require ZOO_THEME_DIR.'inc/customize/options/sidebar-style.php',
     9 => require ZOO_THEME_DIR.'inc/customize/options/blog-style.php',
     10 => require ZOO_THEME_DIR.'inc/customize/options/form-style.php',
     11 => require ZOO_THEME_DIR.'inc/customize/options/woocommerce-style.php',
     12 => require ZOO_THEME_DIR.'inc/customize/options/typography.php',
];
