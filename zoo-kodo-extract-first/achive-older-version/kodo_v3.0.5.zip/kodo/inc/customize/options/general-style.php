<?php
/**
 * Customize for General Style
 */
return [
    [
        'name' => 'zoo_style',
        'type' => 'panel',
        'label' => esc_html__('Style', 'kodo'),
    ], [
        'name' => 'zoo_general_style',
        'type' => 'section',
        'label' => esc_html__('General Style', 'kodo'),
        'panel' => 'zoo_style',
        'description' => esc_html__('Leave option blank if you want use default style of theme.', 'kodo'),
    ],
    [
        'name' => 'zoo_general_style_heading_color',
        'type' => 'heading',
        'section' => 'zoo_general_style',
        'title' => esc_html__('Color', 'kodo'),
    ],
    [
        'name' => 'zoo_color_preset',
        'type' => 'select',
        'section' => 'zoo_general_style',
        'title' => esc_html__('Preset', 'kodo'),
        'description' => esc_html__('Predefined color scheme to Style', 'kodo'),
        'default' => 'default',
        'choices' => [
            'default' => esc_html__('Default', 'kodo'),
            'black' => esc_html__('Black', 'kodo'),
            'blue' => esc_html__('Blue', 'kodo'),
            'red' => esc_html__('Red', 'kodo'),
            'yellow' => esc_html__('Yellow', 'kodo'),
            'green' => esc_html__('Green', 'kodo'),
            'grey' => esc_html__('Grey', 'kodo'),
            'custom' => esc_html__('Custom', 'kodo'),
        ]
    ],
    [
        'name' => 'zoo_primary_color',
        'type' => 'color',
        'section' => 'zoo_general_style',
        'title' => esc_html__('Primary color', 'kodo'),
        'selector' => ".accent-color",
        'css_format' => 'color: {{value}};',
        'description' => esc_html__('Primary color of theme apply only when preset is custom.', 'kodo'),
        'required'=>['zoo_color_preset','==','custom']
    ],[
        'name' => 'zoo_site_color',
        'type' => 'color',
        'section' => 'zoo_general_style',
        'title' => esc_html__('Text color', 'kodo'),
        'selector' => "body",
        'css_format' => 'color: {{value}};',
    ],[
        'name' => 'zoo_site_link_color',
        'type' => 'color',
        'section' => 'zoo_general_style',
        'title' => esc_html__('Link color', 'kodo'),
        'selector' => "a",
        'css_format' => 'color: {{value}};',
    ],[
        'name' => 'zoo_site_link_color_hover',
        'type' => 'color',
        'section' => 'zoo_general_style',
        'title' => esc_html__('Link color hover', 'kodo'),
        'selector' => "a:hover",
        'css_format' => 'color: {{value}};',
    ],[
        'name' => 'zoo_site_heading_color',
        'type' => 'color',
        'section' => 'zoo_general_style',
        'title' => esc_html__('Heading color', 'kodo'),
        'selector' => "h1, h2, h3, h4, h5, h6",
        'css_format' => 'color: {{value}};',
    ],
    [
        'name' => 'zoo_general_heading_bg',
        'type' => 'heading',
        'section' => 'zoo_general_style',
        'title' => esc_html__('Background', 'kodo'),
    ],
    [
        'name' => 'zoo_general_bg',
        'type' => 'styling',
        'section' => 'zoo_general_style',
        'title'  => esc_html__('Background', 'kodo'),
        'selector' => [
            'normal' => "body",
        ],
        'field_class'=>'no-hide no-heading',
        'css_format' => 'styling', // styling
        'fields' => [
            'normal_fields' => [
                'text_color' => false,
                'link_color' => false,
                'link_hover_color' => false,
                'padding' => false,
                'box_shadow' => false,
                'border_radius' => false,
                'border_style' => false,
                'border_heading' => false,
                'bg_heading' => false,
                'margin' => false
            ],
            'hover_fields' => false
        ]
    ],
];
