<?php
/**
 * Customize for Shop loop product
 */
return [
    [
        'name'           => 'zoo_shop_columns_settings',
        'type'           => 'heading',
        'label'          => esc_html__( 'Columns Settings', 'kodo' ),
        'description' => esc_html__( 'Product per page will be sum of Rows per page and Products per row.', 'kodo' ),
        'section'        => 'woocommerce_product_catalog',
        'theme_supports' => 'woocommerce'
    ],
    [
        'name'        => 'zoo_shop_cols_tablet',
        'type'        => 'number',
        'label'       => esc_html__( 'Shop loop columns on Tablet', 'kodo' ),
        'section'     => 'woocommerce_product_catalog',
        'unit'        => false,
        'input_attrs' => array(
            'min'   => 1,
            'max'   => 6,
            'class' => 'zoo-range-slider'
        ),
        'default'     => 2,
    ],
    [
        'name'        => 'zoo_shop_cols_mobile',
        'type'        => 'number',
        'label'       => esc_html__( 'Shop loop columns on Mobile', 'kodo' ),
        'section'     => 'woocommerce_product_catalog',
        'input_attrs' => array(
            'min'   => 1,
            'max'   => 6,
            'class' => 'zoo-range-slider'
        ),
        'default'     => 2,
    ],
    [
        'name'           => 'zoo_shop_general_settings',
        'type'           => 'heading',
        'label'          => esc_html__( 'General Settings', 'kodo' ),
        'section'        => 'woocommerce_product_catalog',
        'theme_supports' => 'woocommerce',
        'order'=>-1
    ],
    [
        'name'           => 'zoo_enable_catalog_mod',
        'type'           => 'checkbox',
        'section'        => 'woocommerce_product_catalog',
        'label'          => esc_html__( 'Enable Catalog Mod', 'kodo' ),
        'checkbox_label' => esc_html__( 'Will be enabled if checked.', 'kodo' ),
        'theme_supports' => 'woocommerce',
        'default'        => 0
    ],
    [
        'name'           => 'zoo_enable_free_shipping_notice',
        'type'           => 'checkbox',
        'section'        => 'woocommerce_product_catalog',
        'label'          => esc_html__( 'Enable Free Shipping Notice', 'kodo' ),
        'checkbox_label' => esc_html__( 'Free shipping thresholds will show in cart if checked.', 'kodo' ),
        'theme_supports' => 'woocommerce',
        'default'        => 1,
    ],
    [
        'name'           => 'zoo_enable_shop_heading',
        'type'           => 'checkbox',
        'section'        => 'woocommerce_product_catalog',
        'label'          => esc_html__( 'Enable Shop Heading', 'kodo' ),
        'checkbox_label' => esc_html__( 'Display product archive title and description.', 'kodo' ),
        'theme_supports' => 'woocommerce',
        'default'        => 1,
    ],[
        'name'           => 'zoo_enable_cat_des',
        'type'           => 'checkbox',
        'section'        => 'woocommerce_product_catalog',
        'label'          => esc_html__( 'Enable Product Category Description', 'kodo' ),
        'checkbox_label' => esc_html__( 'Display product description and thumbnail.', 'kodo' ),
        'theme_supports' => 'woocommerce',
        'default'        => 1,
    ],
    [
        'name'        => 'zoo_shop_banner',
        'type'        => 'image',
        'section'     => 'woocommerce_product_catalog',
        'title'       => esc_html__( 'Shop banner', 'kodo' ),
        'description' => esc_html__( 'Banner image display at top Products page. It will override by Category image.', 'kodo' ),
        'required'    => [ 'zoo_enable_shop_heading', '==', '1' ],
    ],
    [
        'name'           => 'zoo_shop_layout_settings',
        'type'           => 'heading',
        'label'          => esc_html__( 'Layout Settings', 'kodo' ),
        'section'        => 'woocommerce_product_catalog',
        'theme_supports' => 'woocommerce'
    ],
    [
        'name'    => 'zoo_shop_sidebar',
        'type'    => 'select',
        'section' => 'woocommerce_product_catalog',
        'title'   => esc_html__( 'Shop Sidebar', 'kodo' ),
        'default' => 'left',
        'choices' => [
            'top'        => esc_html__( 'Top (Horizontal)', 'kodo' ),
            'left'       => esc_html__( 'Left', 'kodo' ),
            'right'      => esc_html__( 'Right', 'kodo' ),
            'off-canvas' => esc_html__( 'Off canvas', 'kodo' ),
        ]
    ],
    [
        'type'           => 'checkbox',
        'name'           => 'zoo_shop_full_width',
        'label'          => esc_html__( 'Enable Shop Full Width', 'kodo' ),
        'section'        => 'woocommerce_product_catalog',
        'default'        => '0',
        'checkbox_label' => esc_html__( 'Shop layout will full width if enabled.', 'kodo' ),
    ],
    [
        'type'           => 'checkbox',
        'name'           => 'zoo_enable_shop_loop_item_border',
        'label'          => esc_html__( 'Enable Product border', 'kodo' ),
        'section'        => 'woocommerce_product_catalog',
        'default'        => '0',
        'checkbox_label' => esc_html__( 'Enable border for product item.', 'kodo' ),
    ],
    [
        'type'           => 'checkbox',
        'name'           => 'zoo_enable_highlight_featured_product',
        'label'          => esc_html__( 'Enable High light Featured Product', 'kodo' ),
        'section'        => 'woocommerce_product_catalog',
        'default'        => '0',
        'checkbox_label' => esc_html__( 'Featured product will display bigger more than another product.', 'kodo' ),
    ],
    [
        'type'        => 'number',
        'name'        => 'zoo_shop_loop_item_gutter',
        'label'       => esc_html__( 'Product Gutter', 'kodo' ),
        'section'     => 'woocommerce_product_catalog',
        'description' => esc_html__( 'White space between product item.', 'kodo' ),
        'input_attrs' => array(
            'min'   => 0,
            'max'   => 100,
            'class' => 'zoo-range-slider'
        ),
        'default'     => 30
    ],
    [
        'name'           => 'zoo_shop_product_item_settings',
        'type'           => 'heading',
        'label'          => esc_html__( 'Product Item Settings', 'kodo' ),
        'section'        => 'woocommerce_product_catalog',
        'theme_supports' => 'woocommerce'
    ],
    [
        'name' => 'zoo_product_hover_effect',
        'type' => 'select',
        'section' => 'woocommerce_product_catalog',
        'title' => esc_html__('Hover Effect', 'kodo'),
        'description' => esc_html__('Hover Effect of product item when hover.', 'kodo'),
        'default' => 'default',
        'choices' => [
            'default' => esc_html__('Default', 'kodo'),
            'style-2' => esc_html__('Style 2', 'kodo'),
            'style-3' => esc_html__('Style 3', 'kodo'),
            'style-4' => esc_html__('Style 4', 'kodo'),
            'style-5' => esc_html__('Style 5', 'kodo'),
            'style-6' => esc_html__('Style 6', 'kodo'),
        ]
    ],
    [
        'name'           => 'zoo_enable_shop_loop_cart',
        'type'           => 'checkbox',
        'section'        => 'woocommerce_product_catalog',
        'label'          => esc_html__( 'Enable Shop Loop Cart', 'kodo' ),
        'checkbox_label' => esc_html__( 'Button Add to cart will show if checked.', 'kodo' ),
        'theme_supports' => 'woocommerce',
        'default'        => 0,
        'required'       => [ 'zoo_enable_catalog_mod', '!=', 1 ],
    ],
    [
        'name'    => 'zoo_shop_cart_icon',
        'type'    => 'icon',
        'section' => 'woocommerce_product_catalog',
        'title'   => esc_html__( 'Cart icon', 'kodo' ),
        'default' => [
            'type' => 'zoo-icon',
            'icon' => 'zoo-icon-cart'
        ]
    ],
    [
        'type'           => 'checkbox',
        'name'           => 'zoo_enable_alternative_images',
        'label'          => esc_html__( 'Enable Alternative Image', 'kodo' ),
        'section'        => 'woocommerce_product_catalog',
        'default'        => '1',
        'checkbox_label' => esc_html__( 'Alternative Image will show if checked.', 'kodo' ),
    ],
    [
        'type'    => 'select',
        'name'    => 'zoo_sale_type',
        'label'   => esc_html__( 'Sale label type display', 'kodo' ),
        'section' => 'woocommerce_product_catalog',
        'default' => 'text',
        'choices' => [
            'numeric' => esc_html__( 'Numeric', 'kodo' ),
            'text'    => esc_html__( 'Text', 'kodo' ),
        ]
    ],
    [
        'type'           => 'checkbox',
        'name'           => 'zoo_enable_shop_new_label',
        'label'          => esc_html__( 'Show New Label', 'kodo' ),
        'section'        => 'woocommerce_product_catalog',
        'default'        => '1',
        'checkbox_label' => esc_html__( 'Stock New will show if checked.', 'kodo' ),
    ],
    [
        'type'           => 'checkbox',
        'name'           => 'zoo_enable_shop_stock_label',
        'label'          => esc_html__( 'Show Stock Label', 'kodo' ),
        'section'        => 'woocommerce_product_catalog',
        'default'        => '1',
        'checkbox_label' => esc_html__( 'Stock label will show if checked.', 'kodo' ),
    ],
    [
        'type'           => 'checkbox',
        'name'           => 'zoo_enable_quick_view',
        'label'          => esc_html__( 'Enable Quick View', 'kodo' ),
        'section'        => 'woocommerce_product_catalog',
        'default'        => '1',
        'checkbox_label' => esc_html__( 'Button quick view will show if checked.', 'kodo' ),
    ],
    [
        'type'           => 'checkbox',
        'name'           => 'zoo_enable_shop_loop_rating',
        'label'          => esc_html__( 'Show rating', 'kodo' ),
        'section'        => 'woocommerce_product_catalog',
        'default'        => '1',
        'checkbox_label' => esc_html__( 'Show rating in product item if checked.', 'kodo' ),
    ],
    /*Product image thumb for gallery*/
    [
        'name'           => 'zoo_gallery_thumbnail_heading',
        'type'           => 'heading',
        'label'          => esc_html__( 'Gallery Thumbnail', 'kodo' ),
        'section'        => 'woocommerce_product_images',
        'theme_supports' => 'woocommerce'
    ],
    [
        'type'           => 'number',
        'name'           => 'zoo_gallery_thumbnail_width',
        'label'          => esc_html__( 'Gallery Thumbnail Width', 'kodo' ),
        'section'        => 'woocommerce_product_images',
        'default'        => '120',
        'description' => esc_html__( 'Max width of image for gallery thumbnail.', 'kodo' ),
    ],
    [
        'type'           => 'number',
        'name'           => 'zoo_gallery_thumbnail_height',
        'label'          => esc_html__( 'Gallery Thumbnail Height', 'kodo' ),
        'section'        => 'woocommerce_product_images',
        'default'        => '120',
    ],
    [
        'type'           => 'checkbox',
        'name'           => 'zoo_gallery_thumbnail_crop',
        'label'          => esc_html__( 'Crop', 'kodo' ),
        'section'        => 'woocommerce_product_images',
        'default'        => '0',
        'checkbox_label' => esc_html__( 'Crop Gallery Thumbnail.', 'kodo' ),
    ],
];