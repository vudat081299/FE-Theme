<?php
/**
 * Post navigation of single post
 *
 * @package     Zoo Theme
 * @version     3.0.0
 * @author      zootemplate
 * @link        https://www.zootemplate.com/
 * @copyright   Copyright (c) 2018 zootemplate
 
 *
 **/

if (get_theme_mod('zoo_enable_next_previous_posts', '1') == 1) {
    $zoo_next_post = get_next_post();
    $zoo_prev_post = get_previous_post();
    $wrap_class = 'zoo-single-post-nav col-12 col-xl-10';
    if (empty($zoo_prev_post) || empty($zoo_next_post)) {
        $wrap_class .= ' only-1-post';
    }
    ?>
    <section class="<?php echo esc_attr($wrap_class) ?>">
        <?php
        if (!empty($zoo_prev_post)):
            $title = $zoo_prev_post->post_title;
            ?>
            <div class="prev-post zoo-single-post-nav-item">
                <a href="<?php echo esc_url(get_permalink($zoo_prev_post->ID)); ?>"
                   title="<?php echo esc_attr($title); ?>">
                    <?php echo wp_kses_post($title); ?>
                </a>
                <div class="content-single-post-nav-item">
                    <span><i class="cs-font clever-icon-arrow-left-4"></i><?php echo esc_html__('Previous Post', 'kodo'); ?></span>
                    <h4><?php echo wp_kses_post($title); ?></h4>
                </div>
            </div>
        <?php endif; ?>
        <?php if (!empty($zoo_next_post)):
            $title = $zoo_next_post->post_title;
            ?>
            <div class="next-post zoo-single-post-nav-item  pull-right">
                <a href="<?php echo esc_url(get_permalink($zoo_next_post->ID)); ?>"
                   title="<?php echo esc_attr($title); ?>"><?php echo wp_kses_post($title); ?>
                </a>
                <div class="content-single-post-nav-item">
                    <span><?php echo esc_html__('Next Post', 'kodo'); ?>
                        <i class="cs-font clever-icon-arrow-right-4"></i></span>
                    <h4><?php echo wp_kses_post($title); ?></h4>
                </div>

            </div>
        <?php endif; ?>
    </section>
<?php } ?>