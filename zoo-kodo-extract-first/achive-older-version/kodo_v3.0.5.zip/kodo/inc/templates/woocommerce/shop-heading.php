<?php
/**
 * Template display cover image of Archive WooCommerce Page template.
 * @since: zoo-theme 3.0.0
 * @Ver: 3.0.0
 */
if ( ! check_vendor() ) {
	$enable_shop_heading = get_theme_mod( 'zoo_enable_shop_heading', 1 );
	if ( $enable_shop_heading ) {
		$thumb_img=get_theme_mod('zoo_shop_banner','');
		if(isset($thumb_img['url'])){
			$thumb_img=$thumb_img['url'];
		}
		if ( is_product_category() ) {
			global $wp_query;
			$cat          = $wp_query->get_queried_object();
			$thumbnail_id = get_term_meta( $cat->term_id, 'thumbnail_id', true );
			$thumb        = wp_get_attachment_url( $thumbnail_id );
			$thumb_img       = $thumb ? $thumb : $thumb_img;
		}
		?>
		
	    <div id="cover-page" style="height:190px;background:url(<?php echo esc_url($thumb_img)?>) center center/cover no-repeat">
	        <div class="wrap-cover-page container" style="min-height:190px;">
	            <div class="cover-page-inner">
	                <?php if ( is_shop() ) { ?>
	                    <h2 class="title-cover-page"><?php echo woocommerce_page_title(); ?></h2>
				 <!-- <span class="total-product">(<?php echo wc_get_loop_prop( 'total' );?>)</span> -->
	                <?php } else {
	                    the_title( '<h2 class="title-cover-page">', '</h2>' );
	                } woocommerce_breadcrumb();
	                ?>
	            </div>
	        </div>
	    </div>
		<?php
		// woocommerce_taxonomy_archive_description();
	} else {
		if ( is_shop() ) {
			$shop_page   = get_post( wc_get_page_id( 'shop' ) );
			$description = '';
			if ( isset( $shop_page->post_content ) ) {
				$description = wc_format_content( $shop_page->post_content );
			}

			if ( $description ) {
				woocommerce_product_archive_description();
			}
			if ( $enable_shop_heading && get_post_meta(get_the_id(), 'zoo_disable_title', true) != 1) {
				?>
				<h2 class="shop-title"><?php echo woocommerce_page_title(); ?></h2>
				 <!-- <span class="total-product">(<?php echo wc_get_loop_prop( 'total' );?>)</span> -->
				<?php
			}
		}
	}
}
