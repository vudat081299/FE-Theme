/**
* Theme Name:  Kodo
* Theme URI:   http://kodo.wp1.zootemplate.com
* Author:      kodo
* Version:     3.0.5
* Author URI:  https://zootemplate.com
* License:     GNU General Public License v2 or later
* License URI: http://www.gnu.org/licenses/gpl-2.0.html
* Description: Kodo is minimal, faster and lighter WooCommerce theme which packed with features to make sure you never run out of ways to customize your new minimal style store to your needs.
* Text Domain: kodo
* Domain Path: /languages
**/
