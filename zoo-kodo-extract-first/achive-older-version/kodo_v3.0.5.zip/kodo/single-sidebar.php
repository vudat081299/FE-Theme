<?php
/**
 * The sidebar containing the main widget area for single post.
 *
 * @package     Zoo Theme
 * @version     1.0.0
 * @author      zootemplate
 * @link        https://www.zootemplate.com/
 * @copyright   Copyright (c) 2018 zootemplate
 
 */

if(is_active_sidebar(get_theme_mod('zoo_blog_single_sidebar','sidebar'))) {
?>
<aside id="sidebar"
       class="sidebar widget-area col-12 col-md-3" role="complementary">
    <?php dynamic_sidebar(get_theme_mod('zoo_blog_single_sidebar','sidebar')); ?>
</aside>
<?php }