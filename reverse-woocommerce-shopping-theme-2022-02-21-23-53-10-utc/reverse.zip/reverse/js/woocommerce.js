jQuery( function( $ ) {

	// Quantity buttons
	if ( ! String.prototype.getDecimals ) {
		String.prototype.getDecimals = function() {
			var num = this,
				match = ('' + num).match(/(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);
			if ( ! match ) {
				return 0;
			}
			return Math.max( 0, ( match[1] ? match[1].length : 0 ) - ( match[2] ? +match[2] : 0 ) );
		}
	}

	function reverse_refresh_quantity_increments(){
		$( 'div.quantity:not(.buttons_added), td.quantity:not(.buttons_added)' ).addClass( 'buttons_added' ).append( '<input type="button" value="+" class="plus" />' ).prepend( '<input type="button" value="-" class="minus" />' );
	}

	$( document ).on( 'updated_wc_div', function() {
		reverse_refresh_quantity_increments();
	} );

	$( document ).on( 'click', '.plus, .minus', function() {
		// Get values
		var $qty		= $( this ).closest( '.quantity' ).find( '.qty'),
			currentVal	= parseFloat( $qty.val() ),
			max			= parseFloat( $qty.attr( 'max' ) ),
			min			= parseFloat( $qty.attr( 'min' ) ),
			step		= $qty.attr( 'step' );

		// Format values
		if ( ! currentVal || currentVal === '' || currentVal === 'NaN' ) currentVal = 0;
		if ( max === '' || max === 'NaN' ) max = '';
		if ( min === '' || min === 'NaN' ) min = 0;
		if ( step === 'any' || step === '' || step === undefined || parseFloat( step ) === 'NaN' ) step = 1;

		// Change the value
		if ( $( this ).is( '.plus' ) ) {
			if ( max && ( currentVal >= max ) ) {
				$qty.val( max );
			} else {
				$qty.val( ( currentVal + parseFloat( step )).toFixed( step.getDecimals() ) );
			}
		} else {
			if ( min && ( currentVal <= min ) ) {
				$qty.val( min );
			} else if ( currentVal > 0 ) {
				$qty.val( ( currentVal - parseFloat( step )).toFixed( step.getDecimals() ) );
			}
		}

		// Trigger change event
		$qty.trigger( 'change' );
	});

	reverse_refresh_quantity_increments();
	
	//EasyZoom
	if( $('.easyzoom').length > 0 ) {

		// Instantiate EasyZoom instances
		var $easyzoom = $('.easyzoom').easyZoom();

		// Setup thumbnails example
		var api1 = $easyzoom.filter('.easyzoom--with-thumbnails').data('easyZoom');

		$('.thumbnails').on('click reset_image', 'a', function(e) {

			var $this = $(this);

			e.preventDefault();

			// Use EasyZoom's swap method
			api1.swap($this.data('standard'), $this.attr('href'), '');
		});

        // remember  the original featured image 		
        var reverse_current_product_id =false; 	
        var reverse_current_image_src = false;
        var reverse_current_image_link_src = false;
        	
        $( ".variations_form" ).on( "woocommerce_variation_select_change", function (e,v) {
        	
        	if(reverse_current_product_id != false ) {
        		
        		var api1 = $easyzoom.filter(reverse_current_product_id).data('easyZoom');

        		api1.swap(	reverse_current_image_src, 
        					reverse_current_image_link_src,
        					'');
        	//reset the first image to original				
        	$('#product-single-first').attr('href',reverse_current_image_link_src);	
        	$('#product-single-first').data('standard',reverse_current_image_link_src);					
        				
        	}


        	e.preventDefault();
        } );

        $( ".single_variation_wrap" ).on( "show_variation", function ( event, variation ) {
            
        	// change the first image to the variation selected image
        	reverse_current_product_id = '#product-image-'+$(this).data('product_id');
        		
        	if(reverse_current_image_src == false)
                reverse_current_image_src = $(reverse_current_product_id+' .woocommerce-main-image img').attr('src'); 
        	if(reverse_current_image_link_src == false)
                reverse_current_image_link_src = $(reverse_current_product_id).data('initial_img_url'); 
        		
        	var api1 = $easyzoom.filter(reverse_current_product_id).data('easyZoom');

        	api1.swap(variation.image.src, variation.image.url,	'');
        	
            // update the anchor to the current image url 
        	$('#product-single-first').attr('href',variation.image.src);	
        	$('#product-single-first').data('standard',variation.image.url);


        } );

	}

	//Scroll to shipping fields
	if($('#ship-to-different-address-checkbox').length > 0) {
		$("#ship-to-different-address-checkbox").change(function() {
			if(this.checked) {
			    $('html,body').animate({
			        scrollTop: $(".woocommerce-shipping-fields").offset().top},
			        'slow');
			}
		});
	}

});