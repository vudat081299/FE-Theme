<?php
/**
 * Theme Functions
 *
 * @author Gogoneata Cristian <cristian.gogoneata@gmail.com>
 * @package WordPress
 * @subpackage reverse
 */

global $dependency_css;
$dependency_css = array();

define("OKTHEMES_THEMEVERSION","1.0");

@define( 'PARENT_DIR', get_template_directory() );
@define( 'CHILD_DIR', get_stylesheet_directory() );

@define( 'PARENT_URL', get_template_directory_uri() );
@define( 'CHILD_URL', get_stylesheet_directory_uri() );

// Include the helpers
include (PARENT_DIR.'/lib/helpers.php');

// Load plugins
require_once (PARENT_DIR . '/lib/class-tgm-plugin-activation.php');
include (PARENT_DIR . '/lib/register-tgm-plugins.php');

//ACF
if ( class_exists( 'acf' ) ) {
    
    // ACF functions
    include get_template_directory() . '/lib/acf/acf-functions.php';

    //ACF theme customizer
    include get_template_directory() . '/lib/theme-customizer/theme-customize.php';
    
    // Hide ACF field group menu item
    add_filter('acf/settings/show_admin', '__return_false');

    // Include text domain for metaboxes
    function gg_reverse_acf_settings_textdomain( $export_textdomain ) {
        return 'reverse';
    }
    add_filter('acf/settings/export_textdomain', 'gg_reverse_acf_settings_textdomain');

    // ACF metaboxes
    include get_template_directory() . '/lib/metaboxes.php';

}

// ACF fields
include get_template_directory() . '/lib/acf/acf-fields.php';


// Include the importer
require_once PARENT_DIR . '/admin/importer/init.php';

// Include sidebars
require_once (PARENT_DIR . '/lib/sidebars.php');

// Include widgets
require_once (PARENT_DIR . '/lib/widgets.php');

/**
 * Load woocommerce functions
 */
if (gg_reverse_is_wc_activated()) {
    require_once PARENT_DIR . '/lib/theme-woocommerce.php';
}

// Include aq resize
include (PARENT_DIR . '/lib/aq_resizer.php');

// Include aq resize
include (PARENT_DIR . '/lib/retina-support.php');

// Include mobile detect
include_once (PARENT_DIR . '/lib/Mobile_Detect.php');

// Include breadcrumbs
include_once (PARENT_DIR . '/lib/breadcrumbs.php');

// load custom walker menu class file
require (PARENT_DIR . '/lib/nav/class-bootstrapwp_walker_nav_menu.php');


/**
 * Maximum allowed width of content within the theme.
 */
if (!isset($content_width)) {
    $content_width = 1170;
}


/**
 * Setup Theme Functions
 *
 */
if (!function_exists('gg_reverse_theme_setup')):
    function gg_reverse_theme_setup() {

        load_theme_textdomain('reverse', get_template_directory() . '/lang');

        add_theme_support( 'title-tag' );
        add_theme_support( 'automatic-feed-links' );
        add_theme_support( 'post-thumbnails' );
        add_theme_support( 'woocommerce' );
        add_theme_support( 'wc-product-gallery-zoom' );
        add_theme_support( 'wc-product-gallery-lightbox' );
        add_theme_support( 'wc-product-gallery-slider' );
        add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );
        
        $defaults = array(
            'default-color'          => 'ffffff',
            'default-image'          => '',
            'default-repeat'         => '',
            'default-position-x'     => '',
            'wp-head-callback'       => 'gg_reverse_page_background_cb',
        );
        add_theme_support( 'custom-background', $defaults);

        register_nav_menus(
            array(
                'main-menu'   => esc_html__('Main Menu', 'reverse'),
                'footer-menu' => esc_html__('Footer Menu', 'reverse')
            )
        );

        set_post_thumbnail_size('full');
        add_image_size('nav-product-image', 150, 190, array( 'left', 'top' ));

    }
endif;
add_action('after_setup_theme', 'gg_reverse_theme_setup');

if (!function_exists('gg_reverse_page_background_cb')) :
    function gg_reverse_page_background_cb() { 
        $page_background = _get_field('gg_page_background');
        $page_background_style = '';

        if ($page_background) :
        $page_background_style = 'background: url('.esc_url($page_background).');';
        $page_background_style .= ' background-repeat: no-repeat;';
        $page_background_style .= ' background-position: center bottom;';
        //$page_background_style .= ' background-attachment: local;';
        $page_background_style .= ' background-size: inherit;';
        ?>

        <style type="text/css">
            body.pace-done { <?php echo esc_html( $page_background_style ); ?> }
        </style>

        <?php 
        endif;
    }
endif;


/**
 * Load CSS styles for theme.
 *
 */
function gg_reverse_styles_loader() {

    /*Register fonts if acf is not available*/
    if ( ! class_exists( 'acf' ) ) {
        $font_string = 'Oswald:400,300,700|Montserrat:400,700';
        $font_url = add_query_arg( 'family', urlencode( $font_string . '&subset=latin,latin-ext' ), "//fonts.googleapis.com/css" );
        wp_enqueue_style( 'reverse-google-fonts', $font_url, array(), '1.0.0' );
    }

    wp_enqueue_style('reverse-bootstrap', get_template_directory_uri() . '/assets/bootstrap/css/bootstrap.min.css', false, OKTHEMES_THEMEVERSION, 'all');
    wp_enqueue_style('reverse-font-awesome', get_template_directory_uri() . '/assets/font-awesome/css/font-awesome.min.css', false, OKTHEMES_THEMEVERSION, 'all');
    
    /*Site preloader*/
    if( _get_field('gg_site_preloader', 'option', true) ) :
    wp_enqueue_style('pace', get_template_directory_uri() . '/styles/site-loader.css', false, OKTHEMES_THEMEVERSION, 'all');
    endif;
    
    wp_enqueue_style('gg-isotope', get_template_directory_uri() . '/styles/isotope.css', false, OKTHEMES_THEMEVERSION, 'all');
    wp_enqueue_style('gg-magnific', get_template_directory_uri() . '/styles/magnific-popup.css', false, OKTHEMES_THEMEVERSION, 'all');

    //SlickCarousel
    wp_register_style('gg-slickcarousel', get_template_directory_uri() . '/assets/slick/slick.css', false, OKTHEMES_THEMEVERSION, 'all');

    //Form validation and addons
    wp_enqueue_style('bootval', get_template_directory_uri() . '/assets/bootstrap-validator/css/formValidation.min.css', false, OKTHEMES_THEMEVERSION, 'all');

    if (gg_reverse_is_wc_activated()) {
        //wp_register_style('gg-easyzoom', get_template_directory_uri() . '/styles/easyzoom.css', false, OKTHEMES_THEMEVERSION, 'all');
        wp_enqueue_style('gg-woocommerce', get_template_directory_uri() . '/styles/gg-woocommerce.css', false, OKTHEMES_THEMEVERSION, 'all');
    }

    //Default stylesheet
    wp_enqueue_style('reverse-default', get_stylesheet_uri());
    
    //Responsive stylesheet
    wp_enqueue_style('reverse-responsive', get_template_directory_uri() . '/styles/responsive.css', false, OKTHEMES_THEMEVERSION, 'all');

    //Remove strikethrough
    if( _get_field('gg_strikethrough', 'option', false) ) :
        $gg_custom_css = "
                .navbar-nav > li > a:after,
                .footer-social li > a:after,
                .gg-widget h4.widget-title:after,
                .wpb_content_element .wpb_heading:after,
                .vc_widget .widgettitle:after,
                .wpb_heading.wpb_flickr_heading:after,
                .wpb_heading.wpb_contactform_heading:after,
                .wpb_content_element .widgettitle:after,
                .contact-form-mini-header:after,
                .title-subtitle-box.line_over_text h1:after,
                .title-subtitle-box.line_over_text h2:after,
                .title-subtitle-box.line_over_text h3:after,
                .title-subtitle-box.line_over_text h4:after,
                .title-subtitle-box.line_over_text h5:after,
                .title-subtitle-box.line_over_text h6:after,
                .wpb-js-composer .vc_general.vc_cta3 h2:after,
                .gg_posts_grid .grid-title:after,
                #reviews #comments h2:after,
                .woocommerce .product .upsells.products h2:after,
                .woocommerce .product .related.products h2:after,
                .woocommerce .cart-collaterals .cart_totals h2:after,
                .woocommerce .cart-collaterals .cross-sells h2:after,
                body.woocommerce-checkout h2:after,
                body.woocommerce-checkout h3:after,
                .woocommerce form.checkout #customer_details h3:after,
                .woocommerce form.checkout #order_review header.title h3:after,
                body.woocommerce-account h2:after,
                body.woocommerce-account h3:after,
                body.woocommerce-order-received h2:after,
                body.woocommerce-order-received header.title h3:after,
                .woocommerce .yith-wcwl-share h4.yith-wcwl-share-title:after {
                  display: none;
                }";
        wp_add_inline_style( 'reverse-default', $gg_custom_css );
    endif;

}
add_action('wp_enqueue_scripts', 'gg_reverse_styles_loader');

/**
 * Load JavaScript and jQuery files for theme.
 *
 */
function gg_reverse_scripts_loader() {

    $setBase = (is_ssl()) ? "https://" : "http://";

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
    
    wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/assets/bootstrap/js/bootstrap.min.js', array('jquery'),OKTHEMES_THEMEVERSION,true);
    wp_enqueue_script('bootstrap-menu', get_template_directory_uri() . '/js/dropdowns-enhancement.js', array('jquery'),OKTHEMES_THEMEVERSION,true);
    wp_enqueue_script('hoverintent', get_template_directory_uri() . '/js/hoverintent.js', array('jquery'), OKTHEMES_THEMEVERSION, true);
    
    wp_register_script('bootval', get_template_directory_uri() . '/assets/bootstrap-validator/js/formValidation.min.js', array('jquery'), OKTHEMES_THEMEVERSION, true);
    wp_register_script('bootvalboot', get_template_directory_uri() . '/assets/bootstrap-validator/js/bootstrap.js', array('jquery'), OKTHEMES_THEMEVERSION, true);
    wp_register_script('bootvaladdon', get_template_directory_uri() . '/assets/bootstrap-validator/addons/mandatoryIcon.min.js', array('jquery'), OKTHEMES_THEMEVERSION, true);
    
    wp_enqueue_script('isotope', get_template_directory_uri() . '/js/jquery.isotope.min.js', array('jquery'), OKTHEMES_THEMEVERSION, true);
    wp_enqueue_script('gg-magnific', get_template_directory_uri() . '/js/jquery.magnific-popup.min.js', array('jquery'), OKTHEMES_THEMEVERSION, true);

    wp_enqueue_script('imagesloaded', get_template_directory_uri() . '/js/jquery.imagesloaded.min.js', array('jquery'), OKTHEMES_THEMEVERSION, true);
    wp_enqueue_script('waypoints', get_template_directory_uri() . '/js/jquery.waypoints.min.js', array('jquery'), OKTHEMES_THEMEVERSION, true);

    /*Site preloader*/
    if( _get_field('gg_site_preloader', 'option', true) ) :
        wp_enqueue_script('pace',get_template_directory_uri() ."/js/pace.min.js",array('jquery'),OKTHEMES_THEMEVERSION,true);
    endif;

    //Infinite scroll
    wp_register_script('infinitescroll', get_template_directory_uri() . '/js/jquery.infinitescroll.min.js', array('jquery'), OKTHEMES_THEMEVERSION, true);
    wp_register_script('manual-trigger', get_template_directory_uri() . '/js/manual-trigger.js', array('jquery'), OKTHEMES_THEMEVERSION, true);

    //Slick Carousel
    wp_register_script('gg-slickcarousel', get_template_directory_uri() . '/assets/slick/slick.min.js', array('jquery'), OKTHEMES_THEMEVERSION, true);
    
    wp_register_script('countto', get_template_directory_uri() . '/js/jquery.countto.js', array('jquery'), OKTHEMES_THEMEVERSION, true);
    
    //Retina images
    if( _get_field('gg_retina_images', 'option',false) ) :
        wp_enqueue_script('retinajs', get_template_directory_uri() . '/js/retina.min.js', array('jquery'), OKTHEMES_THEMEVERSION, true);
    endif;

    /*Maps*/
    wp_register_script('google-map-api',$setBase."maps.google.com/maps/api/js?key=AIzaSyBakhbP-CkuymO2JwmatJiw_o8Dbf_SZhM&libraries=geometry");
    wp_register_script('maplace',get_template_directory_uri() ."/js/maplace-0.1.3.min.js",array('jquery'),OKTHEMES_THEMEVERSION,true);

    /* Contact form */
    wp_register_script('cfjs', get_template_directory_uri() ."/js/forms/cf.js",array('jquery'),OKTHEMES_THEMEVERSION,true);
    wp_localize_script( 'cfjs', 'ajax_object_cf',
        array(
            'ajax_url' => admin_url( 'admin-ajax.php' )
        )
    );

    /* Contact miniform */
    wp_register_script('cmfjs', get_template_directory_uri() ."/js/forms/cmf.js",array('jquery'),OKTHEMES_THEMEVERSION,true);
    wp_localize_script( 'cmfjs', 'ajax_object_cmf',
        array(
            'ajax_url' => admin_url( 'admin-ajax.php' )
        )
    );

    /* General */
    wp_enqueue_script('custom', get_template_directory_uri() . '/js/custom.js', array('jquery'), OKTHEMES_THEMEVERSION, true);

    $reverse_l10n = array(
        'infinitescroll_img'   => get_template_directory_uri().'/images/animated-ring.gif',
        'infinitescroll_msgText' => esc_html( 'Loading the next set of posts...', 'reverse' ),
        'infinitescroll_finishedMsg' => esc_html( 'All posts loaded.', 'reverse' ),
    );

    wp_localize_script( 'custom', 'reverseScreenReaderText', $reverse_l10n );

}
add_action('wp_enqueue_scripts', 'gg_reverse_scripts_loader');

/**
 * Display template for post meta information.
 *
 */
if (!function_exists('gg_reverse_posted_on')) :
    function gg_reverse_posted_on() {

    $date = sprintf( '<a href="%1$s" title="%2$s" rel="bookmark"><time class="entry-date" datetime="%3$s">%4$s</time></a>',
        esc_url( get_permalink() ),
        esc_attr( get_the_time() ),
        esc_attr( get_the_date( 'c' ) ),
        esc_html( get_the_date() )
    );

    printf($date);    

}
endif;

if ( ! function_exists( 'gg_reverse_posted_on_summary' ) ) :
    function gg_reverse_posted_on_summary() {
        
        if ( is_single() ) {
            echo '<time class="updated" datetime="'. get_the_time( 'c' ) .'">'. sprintf( esc_html__( 'Posted on %s ', 'reverse' ), get_the_date() ) .'</time>';
            echo '<p class="byline author">'. esc_html__( 'by', 'reverse' ) .' <a href="'. get_author_posts_url( get_the_author_meta( 'ID' ) ) .'" rel="author" class="fn">'. get_the_author() .'</a></p>';

            $categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'reverse' ) );
            if ( $categories_list && gg_reverse_categorized_blog() ) {
              printf( '<span class="cat-links"><span> %1$s </span>%2$s</span>',
                _x( 'in', 'Used before category names.', 'reverse' ),
                $categories_list
              );
            }

        } else {
            echo '<p class="byline author">'. esc_html__( 'By', 'reverse' ) .' <a href="'. get_author_posts_url( get_the_author_meta( 'ID' ) ) .'" rel="author" class="fn">'. get_the_author() .'</a></p>';
        }

        if ( the_title( ' ', ' ', false ) == "" ) {
            echo '<time class="updated" datetime="'. get_the_time( 'c' ) .'">'. sprintf( '%1$s <a href="%2$s" rel="bookmark"> %3$s </a>', esc_html__( 'Posted on', 'reverse' ), get_permalink(), get_the_date() ) .'</time>';
        }
        
        //echo '<div class="clearfix"></div>';
    }
endif;

/**
 * Display page header
 *
 */
if ( ! function_exists( 'gg_reverse_page_header' ) ) :

function gg_reverse_page_header() {
    //Get global post id
    $post_id            = gg_reverse_global_page_id();
    
    $page_header        = _get_field('gg_page_header',$post_id, true);
    $page_title         = _get_field('gg_page_title',$post_id,true);
    $page_breadcrumbs   = _get_field('gg_page_breadcrumbs',$post_id,true);
    $page_description   = _get_field('gg_page_description',$post_id,'');
    
    $page_header_slider = _get_field('gg_page_header_slider',$post_id, false);
    $rev_slider_alias   = _get_field('gg_page_header_slider_select',$post_id);

    ?>

    <?php if ($page_header_slider) : ?>
    <div class="subheader-slider">
        <div class="container">
            <?php putRevSlider(esc_html($rev_slider_alias)); ?>
        </div>
    </div>
    <div class="clearfix"></div>
    <?php endif; ?>
           
    <?php
    if ( 
        ($page_header === TRUE || $page_header === NULL) && 
        !is_front_page() &&
        !is_404() 
    ) :
    ?>
        <div class="page-meta">

            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        
                        <div class="page-meta-wrapper">
                        <?php if ( ($page_title === TRUE OR $page_title === NULL) && !is_singular('product') )  : ?>
                        <h1><?php echo gg_reverse_wp_title(); ?></h1>
                        <?php endif; ?>

                        <?php 
                        if ( $page_breadcrumbs === TRUE OR $page_breadcrumbs === NULL ) :
                            if (function_exists('gg_reverse_breadcrumbs')) gg_reverse_breadcrumbs();
                        endif;
                        ?>

                        <?php if ($page_description != '' && is_page() ) { ?>
                        <div class="header-page-description">
                            <?php echo wp_kses_post($page_description); ?>
                        </div>
                        <?php } ?>
                        </div><!-- .page-meta-wrapper -->

                        <!-- Page header image -->
                        <?php if ( has_post_thumbnail($post_id) && is_page() && !is_singular('product') ) : ?>
                        <div class="page-header-image">
                            <?php the_post_thumbnail( 'full' ); ?>
                        </div>
                        <?php endif; ?>

                    </div><!-- .col-md-12 -->
                    
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .page-meta -->
    <?php endif; ?>

<?php
}
endif;

/**
 * Display template for post footer information (in single.php).
 *
 */
if (!function_exists('gg_reverse_posted_in')) :
    function gg_reverse_posted_in() {

    // Translators: used between list items, there is a space after the comma.
    $tag_list = get_the_tag_list('<ul class="list-inline post-tags"><li>','</li><li>','</li></ul>');

    // Translators: 1 is the tags
    if ( $tag_list ) {
        $utility_text = esc_html__( '%1$s', 'reverse' );
    } 

    printf($tag_list);

}
endif;

/**
 * Adds custom classes to the array of body classes.
 *
 */
if (!function_exists('gg_reverse_body_classes')) :
    function gg_reverse_body_classes($classes) {
        if (is_page()):

            $page_header_slider          = _get_field('gg_page_header_slider', gg_reverse_global_page_id(), false);
            $page_header_slider_position = _get_field('gg_page_header_slider_position', gg_reverse_global_page_id(),'under_header');

            if ( has_post_thumbnail( gg_reverse_global_page_id() ) ) {
                $classes[] = 'gg-page-has-header-image';
            }
            if ( $page_header_slider ) {
                $classes[] = 'gg-page-has-header-slider';
            }
            if ( $page_header_slider_position ) {
                $classes[] = 'gg-slider-is-'.$page_header_slider_position.'';
            }
        endif;

        //Header styles
        $overwrite_header_style = _get_field('gg_overwrite_header_style_on_page', gg_reverse_global_page_id(), false);

        if ($overwrite_header_style) {
            $nav_sticky = _get_field('gg_page_sticky_menu',gg_reverse_global_page_id(), false);
            $nav_menu = _get_field('gg_page_menu_style',gg_reverse_global_page_id(), 'style_1');
        } else {
            $nav_sticky = _get_field('gg_sticky_menu','option', false);
            $nav_menu = _get_field('gg_menu_style','option', 'style_1');
        }
        
        if ($nav_sticky) {
            $classes[] = 'gg-has-stiky-menu';
        }

         if ($nav_menu) {
            $classes[] = 'gg-has-'.$nav_menu.'-menu';
        }
        //End header styles

        if (!is_multi_author()) {
            $classes[] = 'single-author';
        }

        if (is_page_template('theme-templates/gallery.php')) {
            $classes[] = 'gg-gallery-template';
        }

        if (is_page_template('theme-templates/contact.php')) {
            $classes[] = 'gg-contact-template';
        }

        if (!_get_field('gg_site_preloader', 'option',true)) {
            $classes[] = 'pace-not-active';
        }

        //WPML
        if ( gg_reverse_is_wpml_activated() ) {
            
            $classes[] = 'gg-theme-has-wpml';
            
            //WPML currency
            if ( class_exists('woocommerce_wpml') ) {
                $classes[] = 'gg-theme-has-wpml-currency';
            }
        }

        

        //Mobile
        $detect = new Mobile_Detect;
        if( $detect->isMobile() || $detect->isTablet() ){
            $classes[] = 'gg-theme-is-mobile';
        }

        return $classes;
    }
    add_filter('body_class', 'gg_reverse_body_classes');
endif;


add_filter( 'the_password_form', 'gg_reverse_password_form' );
function gg_reverse_password_form() {
    global $post;
    $label = 'pwbox-'.(empty($post->ID) ? rand() : $post->ID);
    $output = '<form action="' . esc_url( site_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '" method="post">
 
    <p>' . esc_html__("This post is password protected. To view it please enter your password below:","reverse") . '</p>
 
    <div class="input-group"><span class="input-group-addon"><i class="fa fa-lock"></i></span><label class="sr-only" for="' . esc_attr($label) . '">' . esc_attr__("Password","reverse") . '</label><input name="post_password" id="' . esc_attr($label) . '" type="password" placeholder=' . esc_attr__("Password","reverse") . ' size="20" /><span class="input-group-btn"><input type="submit" name="Submit" value="' . esc_attr__("Submit","reverse") . '" /></span></div></form>'; 
    return $output;
}


/**
 * Replaces the login header logo
 */
if (!function_exists('gg_reverse_admin_login_style')) :
    add_action( 'login_head', 'gg_reverse_admin_login_style' );
    function gg_reverse_admin_login_style() {
        if ( _get_field('gg_display_admin_image_logo', 'option') ) {
            $logo = _get_field('gg_admin_logo_image', 'option');
        ?>
            <style>
            .login h1 a { 
                background-image: url( <?php echo esc_url($logo['url']); ?> ) !important; 
                background-size: <?php echo esc_attr($logo['width']); ?>px <?php echo esc_attr($logo['height']);?>px;
                width:<?php echo esc_attr($logo['width']); ?>px;
                height:<?php echo esc_attr($logo['height']); ?>px;
                margin-bottom:15px; 
            }
            </style>
        <?php
        }
    }
endif;

/**
 * Adds custom CSS
 */
function gg_reverse_options_css() { ?>
<style type="text/css">
    <?php 
    //Always at the end of the file
    if (_get_field('gg_css', 'option') != '') {
        echo _get_field('gg_css', 'option');
    } 
    ?>
</style>
    <?php
}

if ( ! is_admin() ) {
    add_action( 'wp_head', 'gg_reverse_options_css');
}

/**
 * Template Redirect
 * Use archive-event.php for all events and 'event-category' taxonomy archives.
 * @author Bill Erickson
 * @link http://www.billerickson.net/code/use-same-template-for-taxonomy-and-cpt-archive/
 *
 * @param string, default template path
 * @return string, modified template path
 *
 */

add_filter( 'template_include', function ( $template ) {

    if ( is_tax( 'gallery_category' ) ) {
    $new_template = locate_template( array( 'archive-gallery_cpt.php ' ) );
        if ( '' != $new_template ) {
            return $new_template ;
        }
    }

    return $template;

}, PHP_INT_MAX, 2 );

/* Modify the titles */

add_filter( 'get_the_archive_title', function ( $title ) {

    if( is_category() ) {
        $title = single_cat_title( '', false );
    }

    if ( is_post_type_archive() ) {
        $title = post_type_archive_title( '', false );
    }

    return $title;

});