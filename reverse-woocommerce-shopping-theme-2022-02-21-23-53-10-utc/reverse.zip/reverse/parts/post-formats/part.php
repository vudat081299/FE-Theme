<?php
/**
 * The default template for displaying content. Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage reverse
 */
?>

<?php 
wp_enqueue_script('gg-magnific');
wp_enqueue_style('gg-magnific');

global $blog_list_thumbnail, $blog_list_content, $blog_layout;
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<?php if ( !is_single() ) : ?>
		<header class="entry-header">
			<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
		</header><!-- .entry-header -->
		<?php endif; ?>

		<?php gg_reverse_post_thumbnail(); ?>

		<div class="post-meta">
		<?php gg_reverse_posted_on_summary(); ?>
		</div>

		<?php if (!is_search()) : ?>
		<div class="entry-content">
			<?php
			/* translators: %s: Name of current post */
			the_content( sprintf(
				esc_html__( 'Continue reading %s', 'reverse' ),
				the_title( '<span class="screen-reader-text">', '</span>', false )
			) );

			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'reverse' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'reverse' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );
		?>
		</div><!-- .entry-content -->

		<?php else: ?>

		<div class="entry-summary">
			<?php the_excerpt(); ?>
		</div><!-- .entry-summary -->
		
		<?php endif; ?>

		<?php if ( is_single() ) : ?>
		<footer class="entry-meta">
			<?php gg_reverse_entry_meta(); ?>
			<?php edit_post_link( esc_html__( 'Edit', 'reverse' ), '<span class="edit-link">', '</span>' ); ?>
		</footer><!-- .entry-meta -->
		<?php endif; ?>


</article><!-- article -->
