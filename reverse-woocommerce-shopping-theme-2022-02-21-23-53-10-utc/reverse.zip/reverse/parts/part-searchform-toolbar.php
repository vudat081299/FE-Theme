<?php
/**
 * Fullscreen Search Form
 *
 * @package WordPress
 * @subpackage reverse
 */
?>

<div id="fullscreen-searchform">
    <button type="button" class="close">x</button>
    <form method="get" id="searchform" class="" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<input type="search" value="<?php the_search_query(); ?>" placeholder="<?php esc_attr_e( 'Search products', 'woocommerce' ); ?>" name="s" id="s" />
		<button type="submit" id="searchsubmit" class="btn btn-primary"><?php esc_attr_e( 'Search', 'woocommerce' ); ?></button>
	</form>
</div>
