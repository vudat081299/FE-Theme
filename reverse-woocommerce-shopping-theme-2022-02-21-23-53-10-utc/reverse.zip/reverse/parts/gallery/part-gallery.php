<?php
/**
 * @package WordPress
 * @subpackage reverse
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php
	//Load carousel
    wp_enqueue_style( 'gg-slickcarousel' );
    wp_enqueue_script( 'gg-slickcarousel' );
	
	wp_enqueue_script('gg-magnific');
	wp_enqueue_style('gg-magnific');

	$images = _get_field('gg_post_format_gallery');

	if( $images ): ?>
	    <ul class="gg-post-format-gallery gg-slick-carousel" data-mousewheel="false" data-slick='{"slidesToShow": 1, "slidesToScroll": 1, "arrows": true, "infinite": true, "adaptiveHeight": true, "rtl": <?php echo is_rtl() ? 'true' : 'false' ?> }'>
	        <?php foreach( $images as $image ): ?>
	            <li>
	                <a href="<?php echo esc_url($image['url']); ?>">
	                     <img src="<?php echo esc_url($image['sizes']['large']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
	                </a>
	                <p><?php echo esc_html($image['caption']); ?></p>
	            </li>
	        <?php endforeach; ?>
	    </ul>
	<?php endif; ?>

	<div class="gg-offset-content">
		<header class="entry-header">
			<?php
				if ( is_single() ) :
					the_title( '<h1 class="entry-title">', '</h1>' );
				else :
					the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
				endif;
			?>
			<?php gg_reverse_posted_on_summary();	?>
		</header><!-- .entry-header -->

		<div class="entry-content">
				<?php
				/* translators: %s: Name of current post */
				the_content( sprintf(
					esc_html__( 'Continue reading %s', 'reverse' ),
					the_title( '<span class="screen-reader-text">', '</span>', false )
				) );

				wp_link_pages( array(
					'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'reverse' ) . '</span>',
					'after'       => '</div>',
					'link_before' => '<span>',
					'link_after'  => '</span>',
					'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'reverse' ) . ' </span>%',
					'separator'   => '<span class="screen-reader-text">, </span>',
				) );
			?>
		</div><!-- .entry-content -->
		

		<?php if ( is_single() ) : ?>
		<footer class="entry-meta">
			<?php gg_reverse_entry_meta(); ?>
			<?php edit_post_link( esc_html__( 'Edit', 'reverse' ), '<span class="edit-link">', '</span>' ); ?>
		</footer><!-- .entry-meta -->
		<?php endif; ?>
			
	</div>


</article><!-- #post -->


