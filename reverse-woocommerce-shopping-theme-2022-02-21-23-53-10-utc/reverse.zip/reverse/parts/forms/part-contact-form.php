<?php
wp_enqueue_style('bootval');

wp_enqueue_script('bootval');
wp_enqueue_script('bootvalboot');
wp_enqueue_script('bootvaladdon');

wp_enqueue_script('cfjs');
 
$contact_form_headline    = _get_field( 'gg_contact_form_headline' );
$contact_form_description = _get_field( 'gg_contact_form_description' );
?>

<?php if ($contact_form_headline) : ?>
<h3 class="entry-header"><?php echo esc_html($contact_form_headline); ?></h3>
<?php endif; ?>

<?php if ($contact_form_description) : ?>
<p><?php echo esc_html($contact_form_description); ?></p>
<?php endif; ?>

<form id="contact-form"
    data-fv-addons="mandatoryIcon"
    data-fv-addons-mandatoryicon-icon="fa fa-asterisk"

    data-fv-message="This value is not valid" 
    data-fv-feedbackicons-valid="fa fa-check" 
    data-fv-feedbackicons-invalid="fa fa-times" 
    data-fv-feedbackicons-validating="fa fa-refresh">

	<div id="cf-msg"></div><!-- Message display -->

    <div class="form-group">
        <label for="name"><?php esc_html_e( 'Name', 'reverse' ); ?></label>
        <input data-fv-notempty="true" data-fv-notempty-message="<?php esc_html_e( 'The name is required and cannot be empty', 'reverse' ); ?>" type="text" name="name" id="name" value="" class="form-control" data-fv-addons="mandatoryIcon" data-fv-addons-mandatoryicon-icon="glyphicon glyphicon-asterisk" />
    </div>    
    <div class="form-group">    
        <label for="email"><?php esc_html_e( 'Email', 'reverse' ); ?></label>
        <input data-fv-notempty="true" data-fv-notempty-message="<?php esc_html_e( 'The email is required and cannot be empty', 'reverse' ); ?>" data-fv-emailaddress="true" data-fv-emailaddress-message="<?php esc_html_e( 'The input is not a valid email address', 'reverse' ); ?>" type="text" name="email" id="email" value="" class="form-control" data-fv-addons="mandatoryIcon" data-fv-addons-mandatoryicon-icon="glyphicon glyphicon-asterisk" />
    </div>
    <div class="form-group">
        <label for="phone"><?php esc_html_e( 'Phone number', 'reverse' ); ?></label>
        <input data-fv-notempty="true" data-fv-notempty-message="<?php esc_html_e( 'The phone number is required and cannot be empty', 'reverse' ); ?>" type="text" name="phone" id="phone" value="" class="form-control" data-fv-addons="mandatoryIcon" data-fv-addons-mandatoryicon-icon="glyphicon glyphicon-asterisk" />
    </div>
    <div class="form-group">
        <label for="subject"><?php esc_html_e( 'Subject', 'reverse' ); ?></label>
        <input data-fv-notempty="true" data-fv-notempty-message="<?php esc_html_e( 'The subject is required and cannot be empty', 'reverse' ); ?>" type="text" name="subject" id="subject" value="" class="form-control" data-fv-addons="mandatoryIcon" data-fv-addons-mandatoryicon-icon="glyphicon glyphicon-asterisk" />
    </div>
    <div class="form-group">    
        <label for="message"><?php esc_html_e( 'Message', 'reverse' ); ?></label>
        <textarea data-fv-notempty="true" data-fv-notempty-message="<?php esc_html_e( 'The message is required and cannot be empty', 'reverse' ); ?>" name="message" id="message" rows="11" class="form-control" data-fv-addons="mandatoryIcon" data-fv-addons-mandatoryicon-icon="glyphicon glyphicon-asterisk"></textarea>
    </div>
        <input name="action" type="hidden" value="cf_action" />
        <input name="post_id" type="hidden" value="<?php echo esc_html($post->ID); ?>" />
      	<?php wp_nonce_field( 'contact_form_html', '_cf_nonce'); ?>
    <div class="form-group">
     	<button type="submit" id="cfs" class="btn btn-default pull-right"><?php esc_html_e( 'Send', 'reverse' ); ?></button>
    </div>
</form>
