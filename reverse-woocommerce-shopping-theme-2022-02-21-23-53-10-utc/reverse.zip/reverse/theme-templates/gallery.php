<?php
/**
 * Template Name: Gallery page
 *
 * @package WordPress
 * @subpackage reverse
 */
get_header(); ?>

<?php
$gallery_layout       = _get_field('gg_gallery_layout');
$gallery_layout_style = _get_field('gg_gallery_layout_style');
$gallery_columns      = _get_field('gg_gallery_columns','',2);
$gallery_no_posts     = _get_field('gg_gallery_no_of_posts_to_show');

$gallery_pagination = _get_field('gg_gallery_pagination');

//Enqueue infinitescroll
if ($gallery_pagination == 'ajax_load') {
    wp_enqueue_script( 'infinitescroll' );
    wp_enqueue_script( 'manual-trigger' );
}
//Enqueue carousel
if ($gallery_layout != 'carousel' ) {
    wp_enqueue_script( 'gg-isotope' );
    wp_enqueue_style( 'gg-isotope' );
} else {
    //Load carousel
    wp_enqueue_style( 'gg-slickcarousel' );
    wp_enqueue_script( 'gg-slickcarousel' );
    wp_enqueue_script( 'gg-mousewheel' );
}

if ($gallery_layout == 'carousel' ) {
    $isotope_item          = '';
    $is_carousel           = 'gg-slick-carousel';
    $convert_ul            = 'div';
    $convert_li            = 'div';
    $gallery_columns_class ='';
    $gallery_no_posts      = '-1';
    $gallery_pagination    = 'none';

    $carousel_data = '';
    $carousel_data .= ' "arrows": true, ';
    $carousel_data .= ' "dots": false, ';
    $carousel_data .= ' "autoplay": '.($carousel_autoplay == 'yes' ? 'true' : 'false').', ';
    $carousel_data .= ' "infinite": true, ';
    $carousel_data .= ' "variableWidth": true, ';
    $carousel_data .= ' "adaptiveHeight": true, ';
    if (is_rtl()) {
       $carousel_data .= ' "rtl": true, '; 
    }
    $carousel_data .= ' "slidesToScroll": 1 ';

    $carousel_data_html = ' data-mousewheel="true" data-slick=\'{ '.$carousel_data.' }\' ';
} else {
    $isotope_item = 'isotope-item';
    $is_carousel = '';
    $carousel_data_html = '';
}

?>

<section id="content">
    <div class="container">
         <div class="row">
            <div class="<?php gg_reverse_page_container(); ?>">

                <!-- Begin gallery posts -->
                <?php
                    //Load magnific 
                    wp_enqueue_script('gg-magnific');
                    wp_enqueue_style('gg-magnific');

                    $paged = get_query_var('paged') ? get_query_var('paged') : 1;

                    // WP_Query arguments
                    $args = array (
                        'post_type'           => 'gallery_cpt',
                        'posts_per_page'      => $gallery_no_posts, 
                        'ignore_sticky_posts' => true,
                        'paged'               => $paged,
                    );

                    // The Query
                    $gallery_query = new WP_Query( $args );

                    // The Loop
                    if ( $gallery_query->have_posts() ) { ?>
                    <!-- Verify row class for isotope -->
                    <div class="gg_posts_grid">

                    <ul <?php echo ' '.$carousel_data_html; ?> class="el-grid gg-gallery <?php echo esc_attr($is_carousel); ?> <?php if($gallery_layout_style == 'nogap') echo 'nogap-cols'; ?>" data-layout-mode="<?php echo esc_attr($gallery_layout); ?>" data-gap="<?php echo esc_attr($gallery_layout_style); ?>" data-pagination="<?php echo esc_attr($gallery_pagination); ?>" >

                        <?php while ( $gallery_query->have_posts() ) : $gallery_query->the_post(); ?>

                            <li class="col-xs-6 col-md-<?php echo esc_attr(floor( 12 / $gallery_columns )); ?> <?php echo esc_attr($isotope_item); ?>">
                                <?php 
                                if ($gallery_layout == 'carousel' ) {
                                    get_template_part( 'parts/gallery/part','gallery-post-carousel' );
                                } else {
                                    get_template_part( 'parts/gallery/part','gallery-post' );
                                }
                                ?>
                            </li><!-- // gallery item column -->

                        <?php endwhile; ?>
                    </ul>
                    </div>    

                    <?php } else { ?>

                        <div class="no-posts-created"> 
                            <h3><?php esc_html_e( 'Not Found', 'reverse' ); ?></h3>  
                            <p><?php esc_html_e( 'Sorry, No gallery posts created yet.', 'reverse' ); ?></p>  
                        </div>
                        
                    <?php } ?>

                    <?php 
                    if ($gallery_pagination == 'ajax_load') { ?>
                        <div class="load-more-anim"></div>
                        <div class="pagination-load-more">
                            <span class="pagination-span">
                            <?php next_posts_link('Load more posts', $gallery_query->max_num_pages) ?>
                            </span>
                        </div>

                    <?php } else {
                        
                        if (function_exists("gg_reverse_pagination")) {
                            gg_reverse_pagination($gallery_query);
                        }
                    } ?>

                    <?php 
                    // Restore original Post Data    
                    wp_reset_postdata();
                    ?> 

                </div><!-- end page container -->
                <?php gg_reverse_page_sidebar(); ?>

        </div>
    </div>    
</section>

<?php get_footer(); ?>