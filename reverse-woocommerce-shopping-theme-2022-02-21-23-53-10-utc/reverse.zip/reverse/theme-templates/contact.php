<?php
/**
 * Template Name: Contact
 *
 * @package WordPress
 * @subpackage reverse
 */
get_header(); ?>

<?php $contact_form = _get_field( 'gg_contact_form', '', true ); ?>

<section id="content">
    <div class="container">
        <div class="row">
            <div class="<?php gg_reverse_page_container(); ?>">
                
                <?php if( have_rows('gg_contact_addresses') ): ?>

                <div class="contact-details">

                    <?php // loop through the rows of data
                    while ( have_rows('gg_contact_addresses') ) : the_row();
                    ?>
                    <div class="contact-details-row col-md-6">

                        <div class="col-md-6">
                            <?php if (get_sub_field('gg_contact_address')): ?>
                            <address>
                                <?php the_sub_field('gg_contact_address'); ?>
                            </address>
                            <?php endif; ?>

                            <?php if (get_sub_field('gg_contact_show_on_map')): ?>
                            <a class="lightbox-el gg-popup" data-effect="mfp-zoom-in" href="#gg-map-popup"><?php esc_html_e('View on map', 'reverse');?></a>
                            <?php endif; ?>

                        </div>

                        <div class="col-md-6 contact-meta-holder">

                            <?php if (get_sub_field('gg_contact_phone')) : ?>
                            <p>
                                <?php the_sub_field('gg_contact_phone'); ?>
                            </p>
                            <?php endif; ?> 
                            
                            <?php if (get_sub_field('gg_contact_email')) : ?>
                            <p><a class="gg-contact-email" href="mailto:<?php echo antispambot(the_sub_field('gg_contact_email'),1); ?>"><?php echo antispambot(the_sub_field('gg_contact_email')); ?></a></p>
                            <?php endif; ?>

                        </div>

                    </div>

                    <?php endwhile; ?>

                    </div>

                <?php endif; ?>

                <div class="clearfix"></div>

                <?php
                // Start the loop.
                while ( have_posts() ) : the_post();

                    // Include the page content template.
                    get_template_part( 'parts/part', 'page' );

                    // If comments are open or we have at least one comment, load up the comment template.
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;

                // End the loop.
                endwhile;
                ?>

                <div class="clearfix"></div>

                <?php if ($contact_form) : ?>
                <div class="contact-form-wrapper col-xs-12 col-md-4 col-md-offset-4">
                <?php get_template_part( 'parts/forms/part','contact-form' ); ?>
                </div><!--Close .contact-form-wrapper -->
                <?php endif; ?>

            </div><!-- end page container -->
            <?php gg_reverse_page_sidebar(); ?>

        </div><!-- .row -->
    </div><!-- .container -->     
</section>

<?php if( have_rows('gg_contact_addresses') ): ?>

<?php
//Enqueue scripts
wp_enqueue_script('google-map-api');
wp_enqueue_script('maplace');
wp_enqueue_style('gg-magnific');
wp_enqueue_script('gg-magnific');
$map_marker = get_template_directory_uri() .'/images/map-marker.png';
?>

<!-- Map script -->
<script type="text/javascript">
;(function ($, window, undefined) {
$(document).ready(function() {
    var myOptions = {
        mapTypeId: google.maps.MapTypeId.ROADMAP //ROADMAP , SATELLITE , HYBRID , TERRAIN 
    };
    var contact_map = new Maplace({
        locations:
        [
            <?php while ( have_rows('gg_contact_addresses') ) : the_row(); ?>

                <?php if (get_sub_field('gg_contact_show_on_map')) : ?>
                {
                    <?php if (get_sub_field('gg_contact_map_latitude')) : ?>
                    lat: <?php the_sub_field('gg_contact_map_latitude'); ?>,
                    <?php endif; ?>

                    <?php if (get_sub_field('gg_contact_map_longitude')) : ?>
                    lon: <?php the_sub_field('gg_contact_map_longitude'); ?>,
                    <?php endif; ?>

                    icon : <?php echo json_encode($map_marker); ?>,

                    <?php if (get_sub_field('gg_contact_address_title')): ?>
                    title: '<?php the_sub_field('gg_contact_address_title'); ?>',
                    <?php endif; ?>

                    <?php if (get_sub_field('gg_contact_map_infowindow')): ?>
                    html: ['<?php the_sub_field('gg_contact_map_infowindow'); ?>'].join(''),
                    <?php endif; ?>

                    <?php if (get_sub_field('gg_contact_map_zoom')): ?>
                    zoom: <?php the_sub_field('gg_contact_map_zoom'); ?>
                    <?php endif; ?>

                },
                <?php endif; ?>

            <?php endwhile; ?>
        ],

        map_div: '#contact-map',
        map_options: myOptions

    });

    if($('.contact-details a.gg-popup').length > 0) {
        $('.contact-details a.gg-popup').click(function(event){
            contact_map.Load();
        });
    }

});//ready

})(jQuery, this);

</script>

<div id="gg-map-popup" class="white-popup mfp-with-anim mfp-hide">
    <div id="contact-map"></div>
</div>


<?php endif; ?>

<?php get_footer(); ?>