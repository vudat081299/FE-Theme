<?php
/**
 * Default Page Header
 *
 * @package WordPress
 * @subpackage reverse
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	
	<!--[if lt IE 9]>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
	<![endif]-->

	<!--[if IE ]>
    <link href="<?php echo get_template_directory_uri() . '/styles/ie.css'; ?>" rel="stylesheet" type="text/css">
    <![endif]-->

	<script>(function(){document.documentElement.className='js'})();</script>

	<?php if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ) :

		if ( _get_field('gg_display_favicon', 'option', true) ) : 

		//Theme Favicon
	    $default_favicon = array(
	        'url' => get_template_directory_uri() . '/images/favicon.png',
	    );

	    $favicon = _get_field('gg_favicon_image', 'option', $default_favicon['url']);
	    //If logo is not yet imported display default logo
	    if ($favicon == false)
	        $favicon = $default_favicon['url'];
	?>
        <link rel="shortcut icon" href="<?php echo esc_url($favicon); ?>" />
    	<?php endif; ?>
	<?php endif; ?>  

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php get_template_part( 'lib/headers/header','default' ); ?>

<?php 
if ( gg_reverse_is_wc_activated() && _get_field('gg_header_search','option', true) === true ) {
	get_template_part( 'parts/part','searchform-toolbar' );
}
?>