<?php
//Remove the horizontal/vertical option
vc_remove_param ('vc_images_carousel', 'mode' );
vc_remove_param ('vc_images_carousel', 'img_size' );
vc_remove_param ('vc_images_carousel', 'speed' );
vc_remove_param ('vc_images_carousel', 'wrap' );

//Remove the horizontal/vertical option
vc_remove_param ('vc_images_carousel', 'partial_view' );

//Image style
vc_add_param("vc_images_carousel", array(
      "type" => "dropdown",
      "heading" => esc_html__("Image style", "reverse"),
      "param_name" => "img_style",
      "value" => $img_style_arr,
      "std" => "default",
      "description" => esc_html__("Choose the image style", "reverse")
  )
);

//Image size
vc_add_param("vc_images_carousel", array(
      "type" => "dropdown",
      "heading" => esc_html__("Image size", "reverse"),
      "param_name" => "img_size",
      "value" => array(esc_html__("Full size", "reverse") => "fullsize", esc_html__("Custom size", "reverse") => "customsize"),
      "description" => esc_html__("Choose the image size", "reverse")
  )
);
vc_add_param("vc_images_carousel", array(
      "type" => "textfield",
      "heading" => esc_html__("Custom size - width", "reverse"),
      "param_name" => "customsize_width",
      "description" => esc_html__("Insert the width of the image", "reverse"),
      "dependency" => Array('element' => "img_size", 'value' => array('customsize'))
  )
);
vc_add_param("vc_images_carousel", array(
      "type" => "textfield",
      "heading" => esc_html__("Custom size - height", "reverse"),
      "param_name" => "customsize_height",
      "description" => esc_html__("Insert the height of the image", "reverse"),
      "dependency" => Array('element' => "img_size", 'value' => array('customsize'))
  )
);

//Modify slides per view with select box
vc_add_param("vc_images_carousel", array(
      "type" => "dropdown",
      "heading" => esc_html__("Slides per view", "reverse"),
      "param_name" => "slides_per_view",
      "value" => array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10),
      "description" => esc_html__("Set numbers of slides you want to display at the same time on slider's container for carousel mode.", "reverse")
  )
);

vc_add_param("vc_images_carousel", $add_css_animation);

?>