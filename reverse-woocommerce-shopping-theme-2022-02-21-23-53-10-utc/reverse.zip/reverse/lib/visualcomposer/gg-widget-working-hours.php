<?php
class WPBakeryShortCode_gg_Widget_Working_Hours extends WPBakeryShortCode {

   public function __construct() {  
         add_shortcode('widget_working_hours', array($this, 'gg_widget_working_hours'));  
   }

   public function gg_widget_working_hours( $atts, $content = null ) { 

         $output = $title = $monday_friday = $saturday = $sunday = $other_details = '';
         extract(shortcode_atts(array(
             'title'         => '',
             'monday_friday' => '',
             'saturday'      => '',
             'sunday'        => '',
             'other_details' => '',
             'extra_class'   => ''
         ), $atts));

         
         $output = '<div class="vc_widget vc_widget_working_hours '.$extra_class.'">';
         $type = 'gg_Working_Hours_Widget';
         $args = array();

         ob_start();
         the_widget( $type, $atts, $args );
         $output .= ob_get_clean();

         $output .= '</div>';

         return $output;
   }
}

$WPBakeryShortCode_gg_Widget_Working_Hours = new WPBakeryShortCode_gg_Widget_Working_Hours();


vc_map( array(
   "name"              => esc_html__("Widget: Working Hours", "reverse"),
   "description"       => esc_html__('Display the working hours', 'reverse'),
   "base"              => "widget_working_hours",
   "weight"            => -50,
   "icon"              => "gg_vc_icon",
   'admin_enqueue_css' => array(get_template_directory_uri().'/lib/visualcomposer/styles.css'),
   "category"          => esc_html__('Reverse', 'reverse'),
   "params" => array(
      array(
         "type" => "textfield",
         "heading" => esc_html__("Title", "reverse"),
         "param_name" => "title",
         "description" => esc_html__("Insert title here", "reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Monday - Friday", "reverse"),
         "param_name" => "monday_friday",
         "admin_label" => true,
         "description" => esc_html__("Insert the hours for monday to friday", "reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Saturday", "reverse"),
         "param_name" => "saturday",
         "description" => esc_html__("Insert the hours for Saturday", "reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Sunday", "reverse"),
         "param_name" => "sunday",
         "description" => esc_html__("Insert the hours for Sunday", "reverse")
      ),
      array(
         "type" => "textarea",
         "heading" => esc_html__("Other details", "reverse"),
         "param_name" => "other_details",
         "description" => esc_html__("Insert other details here", "reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Extra class", "reverse"),
         "param_name" => "extra_class",
         "description" => esc_html__("Insert an extra class to style the widget differently. This widget has already a class styled for dark background: contact_widget_dark ", "reverse")
      ),

   )
) );

?>