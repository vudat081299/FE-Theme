<?php
if(!function_exists('infobox_item_output')){
    
    function infobox_item_output( $atts, $content = null){
        
        $output = $group = '';
        $atts =  extract(shortcode_atts( 
            array( 
                'infobox_style'        => 'horizontal',
                'infobox_text_align'   => 'center',
                'infobox_border_style' => 'full-border'
        ),$atts )) ;

        if ($infobox_style == 'vertical') {
            $group = 'vertical';
        } else {
            $group = 'justified';
        }

        $output  .= '<ul class="gg-infobox '.$infobox_border_style.' btn-group btn-group-'.$group.' text-'.$infobox_text_align.'">';
        $output .= do_shortcode( $content );
        $output .= '</ul>';

        return $output;
    }

    add_shortcode( 'infobox_item' , 'infobox_item_output' );
}

if(!function_exists('infobox_inner_item_output')){
    
    function infobox_inner_item_output($atts, $content = null){
        
        $output = $title = $subtitle = $link = '';
        extract(shortcode_atts(array(
            'title'    => '',
            'subtitle' => '',
            'link'     => '',
        ), $atts));

        $attributes = array();
        //parse link
        $link = ( '||' === $link ) ? '' : $link;
        $link = vc_build_link( $link );
        $use_link = false;
        if ( strlen( $link['url'] ) > 0 ) {
            $use_link = true;
            $a_href = $link['url'];
            $a_title = $link['title'];
            $a_target = strlen( $link['target'] ) > 0 ? $link['target'] : '_self';
        }

        if ( $use_link ) {
            $attributes[] = 'href="' . esc_url( trim( $a_href ) ) . '"';
            $attributes[] = 'title="' . esc_attr( trim( $a_title ) ) . '"';
            $attributes[] = 'target="' . esc_attr( trim( $a_target ) ) . '"';
        }

        $attributes = implode( ' ', $attributes );

        $output  = "\n\t".'<li class="btn-group">';
        if ( $use_link ) {
            $output .= "\n\t\t".'<a '.$attributes.'></a>';
        }
        $output .= "\n\t\t".'<h5>'.$title.'</h5>';
        $output .= "\n\t\t".'<p>'.$subtitle.'</p>';
        $output .= "\n\t".'</li> ';

        return $output;
    }

    add_shortcode( 'infobox_inner_item' , 'infobox_inner_item_output' );
}

// Parent container
vc_map( array(
    'name'                    => esc_html__( 'Infobox Item' , 'reverse' ),
    'base'                    => 'infobox_item',
    'icon'                    => 'icon-wpb-row',
    "icon"                    => "gg_vc_icon",
    "weight"                  => -50,
    'admin_enqueue_css'       => array(get_template_directory_uri().'/lib/visualcomposer/styles.css'),
    'description'             => esc_html__( 'Container for Item', 'reverse' ),
    "category"                => esc_html__('Reverse', 'reverse'),
    'as_parent'               => array('only' => 'infobox_inner_item'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    'content_element'         => true,
    'show_settings_on_create' => true,
    'params'                  => array(

                //BEGIN ADDING PARAMS
                array(
                    "type" => "dropdown",
                    "heading" => esc_html__("Infobox style", "reverse"),
                    "param_name" => "infobox_style",
                    "value" => array(
                        esc_html__("Horizontal", "reverse") => "horizontal", 
                        esc_html__("Vertical", "reverse") => "vertical"
                    ),
                    "description" => esc_html__("Choose the infobox style", "reverse")
                ),
                array(
                    "type" => "dropdown",
                    "heading" => esc_html__("Infobox border style", "reverse"),
                    "param_name" => "infobox_border_style",
                    "value" => array(
                        esc_html__("Full border", "reverse") => "full-border", 
                        esc_html__("Fine line", "reverse") => "fine-line"
                    ),
                    "description" => esc_html__("Choose the infobox style", "reverse")
                ),
                array(
                    "type" => "dropdown",
                    "heading" => esc_html__("Infobox text align", "reverse"),
                    "param_name" => "infobox_text_align",
                    "value" => array(
                        esc_html__("Center", "reverse") => "center",
                        esc_html__("Left", "reverse")   => "left", 
                        esc_html__("Right", "reverse")  => "right",
                    ),
                    "description" => esc_html__("Choose the infobox style", "reverse")
                ),

                //END ADDING PARAMS

    ),
    "js_view" => 'VcColumnView'
) );

// Nested Element
vc_map( array(
    'name'            => esc_html__('Infobox Items', 'reverse'),
    'base'            => 'infobox_inner_item',
    'description'     => esc_html__( 'Items "Item".', 'reverse' ),
    'icon'            => 'icon-wpb-row',
    'content_element' => true,
    'as_child'        => array('only' => 'infobox_item'), // Use only|except attributes to limit parent (separate multiple values with comma)
    'params'          => array(
                
                //BEGIN ADDING PARAMS
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Title","reverse"),
                    "param_name" => "title",
                    "admin_label" => true,
                    "description" => esc_html__("Insert the title here","reverse")
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Subtitle","reverse"),
                    "param_name" => "subtitle",
                    "admin_label" => true,
                    "description" => esc_html__("Insert the subtitle here","reverse")
                ),
                array(
                    'type' => 'vc_link',
                    'heading' => esc_html__( 'URL (Link)', 'reverse' ),
                    'param_name' => 'link',
                    'description' => esc_html__( 'Add link to title.', 'reverse' )
                ),
               //END ADDING PARAMS
    ),
) );

// A must for container functionality, replace infobox_Item with your base name from mapping for parent container
if(class_exists('WPBakeryShortCodesContainer'))
{
    class WPBakeryShortCode_infobox_Item extends WPBakeryShortCodesContainer {

    }
}

// Replace infobox_inner_item with your base name from mapping for nested element
if(class_exists('WPBakeryShortCode'))
{
    class WPBakeryShortCode_infobox_Inner_Item extends WPBakeryShortCode {

    }
}


?>