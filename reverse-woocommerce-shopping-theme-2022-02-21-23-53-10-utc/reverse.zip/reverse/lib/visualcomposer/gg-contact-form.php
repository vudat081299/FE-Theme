<?php
class WPBakeryShortCode_gg_contact_form extends WPBakeryShortCode {

   public function __construct() {  
         add_shortcode('contact_form', array($this, 'gg_contact_form'));  
   }

   public function gg_contact_form( $atts, $content = null ) { 

         $output = $email_address = $success_message = $error_message = '';
         extract(shortcode_atts(array(
             'form_title' => '',
             'email_address'    => '',
             'success_message'  => 'Your message was sent successfully.',
             'error_message'   => 'There was an error submitting the form.'
         ), $atts));

          ob_start();
          set_query_var( 'form_title', $form_title );
          set_query_var( 'email_address', $email_address );
          set_query_var( 'success_message', $success_message );
          set_query_var( 'error_message', $error_message );

          get_template_part( 'parts/forms/part','contact-miniform' );
          $output .= "\n\t".ob_get_contents();
          ob_end_clean();

         return $output;
         
   }
}

$WPBakeryShortCode_gg_contact_form = new WPBakeryShortCode_gg_contact_form();  

vc_map( array(
   "name"              => esc_html__("Contact form","reverse"),
   "description"       => esc_html__('Display a mini contact form.', 'reverse'),
   "base"              => "contact_form",
   "icon"              => "gg_vc_icon",
   "weight"            => -50,
   'admin_enqueue_css' => array(get_template_directory_uri().'/lib/visualcomposer/styles.css'),
   "category"          => esc_html__('Reverse', 'reverse'),
   "params" => array(
      array(
         "type" => "textfield",
         "heading" => esc_html__("Form title","reverse"),
         "param_name" => "form_title",
         "value" => '',
         "admin_label" => true,
         "description" => esc_html__("Insert widget title here","reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Email","reverse"),
         "param_name" => "email_address",
         "admin_label" => true,
         "description" => esc_html__("Insert the contact form email here.","reverse")
      ),
      array(
          "type" => "textfield",
          "heading" => esc_html__('Success message', 'reverse'),
          "param_name" => "success_message",
          "value" => 'Your message was sent successfully.',
          "description" => esc_html__("Insert the success message.", "reverse")
      ),
      array(
          "type" => "textfield",
          "heading" => esc_html__('Error message', 'reverse'),
          "param_name" => "error_message",
          "value" => 'There was an error submitting the form.',
          "description" => esc_html__("Insert the error message.", "reverse")
      ),

      $add_css_animation,

   )
) );

?>