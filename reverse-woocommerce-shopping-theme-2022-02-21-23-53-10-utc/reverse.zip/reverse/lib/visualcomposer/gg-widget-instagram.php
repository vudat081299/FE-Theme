<?php
class WPBakeryShortCode_gg_Widget_Instagram extends WPBakeryShortCode {

   public function __construct() {  
         add_shortcode('widget_instagram', array($this, 'gg_widget_instagram'));  
   }

   public function gg_widget_instagram( $atts, $content = null ) { 

         $output = $title = $username = $posts = '';
         extract(shortcode_atts(array(
               'title'    => '',
               'username' => '',
               'link'     => 'Follow us',
               'number'    => 9,
               'followers'    => ''
         ), $atts));

         
         $output = '<div class="vc_widget vc_widget_instagram">';
         $type = 'gg_instagram_widget';
         $args = array();

         ob_start();
         the_widget( $type, $atts, $args );
         $output .= ob_get_clean();

         $output .= '</div>';

         return $output;
   }
}

$WPBakeryShortCode_gg_Widget_Instagram = new WPBakeryShortCode_gg_Widget_Instagram();


vc_map( array(
   "name"              => esc_html__("Widget: Instagram", "reverse"),
   "description"       => esc_html__('Display Instagram posts.', 'reverse'),
   "base"              => "widget_instagram",
   "weight"            => -50,
   "icon"              => "gg_vc_icon",
   'admin_enqueue_css' => array(get_template_directory_uri().'/lib/visualcomposer/styles.css'),
   "category"          => esc_html__('Reverse', 'reverse'),
   "params" => array(
      array(
         "type" => "textfield",
         "heading" => esc_html__("Title", "reverse"),
         "param_name" => "title",
         "description" => esc_html__("Insert title here", "reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Username", "reverse"),
         "param_name" => "username",
         "admin_label" => true,
         "description" => esc_html__("Insert username here.", "reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Link", "reverse"),
         "param_name" => "link",
         "description" => esc_html__("Insert your link text", "reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Number of posts to display", "reverse"),
         "param_name" => "number",
         "description" => esc_html__("Insert number of posts to display here.", "reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Number of followers", "reverse"),
         "param_name" => "followers",
         "description" => esc_html__("Insert number of followers.", "reverse")
      ),
   )
) );

?>