<?php
class WPBakeryShortCode_gg_Widget_Contact_Us extends WPBakeryShortCode {

   public function __construct() {  
         add_shortcode('widget_contact_us', array($this, 'gg_widget_contact_us'));  
   }

   public function gg_widget_contact_us( $atts, $content = null ) { 

         $output = $title = $company = $address = $phone = $fax = $email = '';
         extract(shortcode_atts(array(
             'title'        => '',
             'address'  => '',
             'phone'  => '',
             'fax'     => '',
             'email' => '',
             'extra_class' => ''
         ), $atts));

         
         $output = '<div class="vc_widget vc_widget_contact_us '.$extra_class.'">';
         $type = 'gg_Contact_Widget';
         $args = array();

         ob_start();
         the_widget( $type, $atts, $args );
         $output .= ob_get_clean();

         $output .= '</div>';

         return $output;
   }
}

$WPBakeryShortCode_gg_Widget_Contact_Us = new WPBakeryShortCode_gg_Widget_Contact_Us();


vc_map( array(
   "name"              => esc_html__("Widget: Contact us", "reverse"),
   "description"       => esc_html__('Display address, phone, fax, email', 'reverse'),
   "base"              => "widget_contact_us",
   "weight"            => -50,
   "icon"              => "gg_vc_icon",
   'admin_enqueue_css' => array(get_template_directory_uri().'/lib/visualcomposer/styles.css'),
   "category"          => esc_html__('Reverse', 'reverse'),
   "params" => array(
      array(
         "type" => "textfield",
         "heading" => esc_html__("Title", "reverse"),
         "param_name" => "title",
         "description" => esc_html__("Insert title here", "reverse")
      ),
      array(
         "type" => "textarea",
         "heading" => esc_html__("Address", "reverse"),
         "param_name" => "address",
         "admin_label" => true,
         "description" => esc_html__("Insert address here", "reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Phone", "reverse"),
         "param_name" => "phone",
         "description" => esc_html__("Insert phone here", "reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Fax", "reverse"),
         "param_name" => "fax",
         "description" => esc_html__("Insert fax here", "reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Email", "reverse"),
         "param_name" => "email",
         "description" => esc_html__("Insert email here", "reverse")
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Extra class", "reverse"),
         "param_name" => "extra_class",
         "description" => esc_html__("Insert an extra class to style the widget differently. This widget has already a class styled for dark background: contact_widget_dark ", "reverse")
      ),

   )
) );

?>