<?php
class WPBakeryShortCode_gg_featured_icon extends WPBakeryShortCode {

   public function __construct() {  
         add_shortcode('featured_icon', array($this, 'gg_featured_icon'));  
   }

   public function gg_featured_icon( $atts, $content = null ) { 

         $output = $margin_style = $style = $icon_box_style_start = $icon_box_style_end = $icon_size_css = $icon_color_css = $featured_title = $image = $align_center = $icon_box_css = $icon_box_back = $icon_border_style = '';
         $icon = $color = $new_color = $align = $el_class = $custom_color = $link = $background_style = $background_color = $type = $icon_fontawesome = $icon_openiconic = $icon_typicons = $icon_entypoicons = $icon_linecons = $css_animation = $read_more_link = $featured_icon_check = '';
         extract(shortcode_atts(array(
             'featured_title'      => '',
             'featured_desc'       => '',
             'link'                => '',
             'featured_icon'       => '',
             'read_more'           => '',
             'read_more_link'      => '',
             'align'               => 'pull-left',
             'icon_box'            => '',
             'icon_box_color'      => '',
             'el_class'            => '',
             'css_animation'       => '',
             'icon_size'           => 'normal',
             'icon_box_style'      => '',
             'icon_color'          => '',
             'icon_border'         => '',
             'featured_icon_check' => '',
             'type'                => 'fontawesome',
             'icon_fontawesome'    => 'fa fa-adjust',
             'icon_openiconic'     => '',
             'icon_typicons'       => '',
             'icon_entypoicons'    => '',
             'icon_linecons'       => '',
             'icon_entypo'         => '',
             'css'                 => '',
             'style'               => 'style_1',
             'replace_color'       => ''
         ), $atts));

        $class = $this->getExtraClass( $el_class );
        $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class, $this->settings['base'], $atts );
        $css_class .= $this->getCSSAnimation( $css_animation );
        $css_class .= $style;
        
        // Enqueue needed icon font.
        vc_icon_element_fonts_enqueue( $type ); 

        $url = vc_build_link( $link );
        $read_more_url = vc_build_link( $read_more_link );
        $has_style = false;

        if ($replace_color) {
          $new_color = 'style="color:'.$replace_color.';"';
        }


        $output .= "\n\t".'<div class="featured-icon-box '.esc_attr( $css_class ).'">';

        if ($featured_icon_check == 'use_featured_icon') {
        $output .= "\n\t".'<div class="vc_icon_element vc_icon_element-outer vc_icon_element-align-pull-left">';
        $output .= "\n\t".'<div class="vc_icon_element-inner vc_icon_element-size-md">';
        $output .= "\n\t".'<span class="vc_icon_element-icon '.esc_attr( ${"icon_" . $type} ).'" '.( $color === 'custom' ? 'style="color:' . esc_attr( $custom_color ) . ' !important"' : '' ).'></span>';
        
          if ( strlen( $link ) > 0 && strlen( $url['url'] ) > 0 ) {
            $output .= "\n\t".'<a class="vc_icon_element-link" href="' . esc_attr( $url['url'] ) . '" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '"></a>';
          }

        $output .= "\n\t".'</div></div>';

        }

        if ( strlen( $url['url'] ) > 0 ) {
          $output .= "\n\t".'<h3 '.$new_color.'><a '.$new_color.' href="' . esc_attr( $url['url'] ) . '" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">'.esc_html($featured_title).'</a></h3>';
        } else {
          $output .= "\n\t".'<h3 '.$new_color.' >'.esc_html($featured_title).'</h3>';
        }

        if ( strlen( $featured_desc ) > 0 ) {
          $output .= "\n\t". '<div class="clearfix"></div><div class="featured-icon-desc" '.$new_color.'>'. wp_kses_post( $featured_desc ).'</div>';
        }

        if ($read_more == 'use_read_more') {
          if ( strlen( $read_more_link ) > 0 && strlen( $read_more_url['url'] ) > 0 ) {
              if ($style == 'style_1') {
                $output .= "\n\t".'<a class="btn btn-default" href="' . esc_attr( $read_more_url['url'] ) . '" title="' . esc_attr( $read_more_url['title'] ) . '" target="' . ( strlen( $read_more_url['target'] ) > 0 ? esc_attr( $read_more_url['target'] ) : '_self' ) . '">' . esc_attr( $read_more_url['title'] ) . '</a>';
              } else {
                $output .= "\n\t".'<a class="more-link" '.$new_color.' href="' . esc_attr( $read_more_url['url'] ) . '" title="' . esc_attr( $read_more_url['title'] ) . '" target="' . ( strlen( $read_more_url['target'] ) > 0 ? esc_attr( $read_more_url['target'] ) : '_self' ) . '">' . esc_attr( $read_more_url['title'] ) . '</a>';
              }
              
            }
        }
        
        $output .= "\n\t".'</div>';

        return $output;
         
   }
}

$WPBakeryShortCode_gg_featured_icon = new WPBakeryShortCode_gg_featured_icon();  

vc_map( array(
   "name" => esc_html__("Featured icon box","reverse"),
   "description" => esc_html__('Display an featured icon with title and description.', 'reverse'),
   "base" => "featured_icon",
   "icon"              => "gg_vc_icon",
   "weight"            => -50,
   'admin_enqueue_css' => array(get_template_directory_uri().'/lib/visualcomposer/styles.css'),
   'admin_enqueue_js' => array(get_template_directory_uri().'/lib/visualcomposer/custom-vc.js'),
   "category" => esc_html__('Reverse', 'reverse'),

   "params" => array(
      array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Style', 'reverse' ),
        'value' => array(
          esc_html__( 'Style 1', 'reverse' ) => 'style_1',
          esc_html__( 'Style 2', 'reverse' ) => 'style_2',
        ),
        'param_name' => 'style',
        'description' => esc_html__( 'Select the style', 'reverse' ),
      ),
      array(
         "type" => "textfield",
         "heading" => esc_html__("Title","reverse"),
         "param_name" => "featured_title",
         "admin_label" => true,
         "description" => esc_html__("Insert title here","reverse")
      ),
      array(
        "type" => "vc_link",
        "heading" => esc_html__("URL (Link)", "reverse"),
        "param_name" => "link",
        "description" => esc_html__("Insert the link.", "reverse"),
        "dependency" => Array('element' => "featured_title", 'not_empty' => true)
      ),
      array(
         "type" => "textarea",
         "heading" => esc_html__("Description","reverse"),
         "param_name" => "featured_desc",
         "description" => esc_html__("Insert short description here","reverse"),
         "dependency" => Array('element' => "featured_title", 'not_empty' => true)
      ),

      array(
         "type" => "checkbox",
         "heading" => esc_html__("Use an Read more link?","reverse"),
         "value" => array(esc_html__("Yes, please","reverse") => "use_read_more" ),
         "param_name" => "read_more",
         "dependency" => Array('element' => "featured_desc", 'not_empty' => true)
      ),

      array(
        "type" => "vc_link",
        "heading" => esc_html__("Read more URL (Link)", "reverse"),
        "param_name" => "read_more_link",
        "description" => esc_html__("Insert the link.", "reverse"),
        "dependency" => Array('element' => "read_more", 'value' => array('use_read_more'))
      ),

      array(
        'type' => 'colorpicker',
        'heading' => esc_html__( 'Overwrite default colors', 'reverse' ),
        'param_name' => 'replace_color',
        'description' => esc_html__( 'Set the new color.', 'reverse' )
      ),

      array(
         "type" => "checkbox",
         "heading" => esc_html__("Use an icon?","reverse"),
         "value" => array(esc_html__("Yes, please","reverse") => "use_featured_icon" ),
         "param_name" => "featured_icon_check"
      ),
      array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Icon library', 'reverse' ),
        'value' => array(
          esc_html__( 'Font Awesome', 'reverse' ) => 'fontawesome',
          esc_html__( 'Open Iconic', 'reverse' ) => 'openiconic',
          esc_html__( 'Typicons', 'reverse' ) => 'typicons',
          esc_html__( 'Entypo', 'reverse' ) => 'entypo',
          esc_html__( 'Linecons', 'reverse' ) => 'linecons',
        ),
        'param_name' => 'type',
        'description' => esc_html__( 'Select icon library.', 'reverse' ),
        "dependency" => Array('element' => "featured_icon_check", 'value' => array('use_featured_icon'))
      ),
      array(
        'type' => 'iconpicker',
        'heading' => esc_html__( 'Icon', 'reverse' ),
        'param_name' => 'icon_fontawesome',
        'value' => 'fa fa-adjust', // default value to backend editor admin_label
        'settings' => array(
          'emptyIcon' => false, // default true, display an "EMPTY" icon?
          'iconsPerPage' => 4000, // default 100, how many icons per/page to display, we use (big number) to display all icons in single page
        ),
        'dependency' => array(
          'element' => 'type',
          'value' => 'fontawesome',
        ),
        'description' => esc_html__( 'Select icon from library.', 'reverse' ),
      ),
      array(
        'type' => 'iconpicker',
        'heading' => esc_html__( 'Icon', 'reverse' ),
        'param_name' => 'icon_openiconic',
        'value' => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
        'settings' => array(
          'emptyIcon' => false, // default true, display an "EMPTY" icon?
          'type' => 'openiconic',
          'iconsPerPage' => 4000, // default 100, how many icons per/page to display
        ),
        'dependency' => array(
          'element' => 'type',
          'value' => 'openiconic',
        ),
        'description' => esc_html__( 'Select icon from library.', 'reverse' ),
      ),
      array(
        'type' => 'iconpicker',
        'heading' => esc_html__( 'Icon', 'reverse' ),
        'param_name' => 'icon_typicons',
        'value' => 'typcn typcn-adjust-brightness', // default value to backend editor admin_label
        'settings' => array(
          'emptyIcon' => false, // default true, display an "EMPTY" icon?
          'type' => 'typicons',
          'iconsPerPage' => 4000, // default 100, how many icons per/page to display
        ),
        'dependency' => array(
          'element' => 'type',
          'value' => 'typicons',
        ),
        'description' => esc_html__( 'Select icon from library.', 'reverse' ),
      ),
      array(
        'type' => 'iconpicker',
        'heading' => esc_html__( 'Icon', 'reverse' ),
        'param_name' => 'icon_entypo',
        'value' => 'entypo-icon entypo-icon-note', // default value to backend editor admin_label
        'settings' => array(
          'emptyIcon' => false, // default true, display an "EMPTY" icon?
          'type' => 'entypo',
          'iconsPerPage' => 4000, // default 100, how many icons per/page to display
        ),
        'dependency' => array(
          'element' => 'type',
          'value' => 'entypo',
        ),
      ),
      array(
        'type' => 'iconpicker',
        'heading' => esc_html__( 'Icon', 'reverse' ),
        'param_name' => 'icon_linecons',
        'value' => 'vc_li vc_li-heart', // default value to backend editor admin_label
        'settings' => array(
          'emptyIcon' => false, // default true, display an "EMPTY" icon?
          'type' => 'linecons',
          'iconsPerPage' => 4000, // default 100, how many icons per/page to display
        ),
        'dependency' => array(
          'element' => 'type',
          'value' => 'linecons',
        ),
        'description' => esc_html__( 'Select icon from library.', 'reverse' ),
      ),
      array(
        'type' => 'colorpicker',
        'heading' => esc_html__( 'Custom Icon Color', 'reverse' ),
        'param_name' => 'custom_color',
        'description' => esc_html__( 'Select custom icon color.', 'reverse' ),
        "dependency" => Array('element' => "featured_icon_check", 'value' => array('use_featured_icon'))
      ),
      array(
      'type' => 'textfield',
      'heading' => esc_html__( 'Extra class name', 'reverse' ),
      'param_name' => 'el_class',
      'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'reverse' )
      ),
      $add_css_animation,
      array(
        'type' => 'css_editor',
        'heading' => esc_html__( 'Css', 'reverse' ),
        'param_name' => 'css',
        'group' => esc_html__( 'Design options', 'reverse' ),
        ),

   ),
  //'js_view'  => 'reverseVcFeaturedIconView',
) );

?>