<?php
class WPBakeryShortCode_gg_List extends WPBakeryShortCode {

   public function __construct() {  
         add_shortcode('list', array($this, 'gg_list'));  
   }

   public function gg_list( $atts, $content = null ) { 

         $output = '';
         extract(shortcode_atts(array(
            'list_style'  => 'remove', //remove,check
            'list_border' => '',
         ), $atts));

         //Start the insanity
         $output = '';
         $output .= "\n\t".'<div class="gg_list list_style_'.$list_style.' ' . ( ($list_border == "yes") ? 'list_border_bottom' : '' ). ' ">'; 
         $output .= $content;         
         $output .= "\n\t".'</div>';

         //return the output
         return $output;
         
   }
}

$WPBakeryShortCode_gg_List = new WPBakeryShortCode_gg_List();  

vc_map( array(
   "name"              => esc_html__("List","reverse"),
   "description"       => esc_html__('List element', 'reverse'),
   "base"              => "list",
   "icon"              => "gg_vc_icon",
   "weight"            => -50,
   'admin_enqueue_css' => array(get_template_directory_uri().'/lib/visualcomposer/styles.css'),
   "category"          => esc_html__('Reverse', 'reverse'),
   "params" => array(
      array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'List style', 'reverse' ),
        'param_name' => 'list_style',
        'value' => array(
          esc_html__( 'Remove icn', 'reverse' )       => 'remove',
          esc_html__( 'Check icn', 'reverse' )        => 'check',
          esc_html__( 'Circle icn', 'reverse' )       => 'circle',
          esc_html__( 'Angle icn', 'reverse' )        => 'angle',
          esc_html__( 'Double angle icn', 'reverse' ) => 'double-angle',
          esc_html__( 'Caret', 'reverse' )            => 'caret',
          esc_html__( 'Heart', 'reverse' )            => 'heart'
        ),
        'description' => esc_html__( 'Select list icon', 'reverse' ),
        "admin_label" => true,
      ),
      array(
        'type' => 'checkbox',
        'heading' => esc_html__( 'Show list item border?', 'reverse' ),
        'param_name' => 'list_border',
        'description' => esc_html__( 'If checked, the list item will have a border', 'reverse' ),
        'value' => array( esc_html__( 'Yes', 'reverse' ) => 'yes' )
      ),
      array(
        'type' => 'textarea_html',
        'holder' => 'div',
        'heading' => esc_html__( 'Text', 'reverse' ),
        'param_name' => 'content',
        'value' => esc_html__( '<ul><li>List item 1</li><li>List item 2</li><li>List item 3</li><li>List item 4</li></ul>', 'reverse' )
      ),
      
   ),
) );

?>