<?php
//Include each file from the visualcomposer directory
foreach (glob(PARENT_DIR.'/lib/visualcomposer/'."*.php") as $filename) {
    include $filename;
}
?>