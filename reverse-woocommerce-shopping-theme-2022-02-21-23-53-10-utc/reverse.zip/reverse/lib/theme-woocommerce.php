<?php
/*
 * Remove default stylesheet
 */
add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

/**
 * Suppress certain WooCommerce admin notices
 */
function gg_reverse_wc_suppress_nags() {
    if ( class_exists( 'WC_Admin_Notices' ) ) {
        // Remove the "you have outdated template files" nag
        WC_Admin_Notices::remove_notice( 'template_files' );
        
        // Remove the "install pages" and "wc-install" nag
        WC_Admin_Notices::remove_notice( 'install' );
    }
}
add_action( 'wp_loaded', 'gg_reverse_wc_suppress_nags', 99 );

/**
 * Load JavaScript for WC
 */
add_action('wp_enqueue_scripts', 'gg_reverse_wc_scripts_loader');
function gg_reverse_wc_scripts_loader() {
    wp_enqueue_script('woo-inputs', get_template_directory_uri() . '/js/woocommerce.js', array('jquery'), OKTHEMES_THEMEVERSION, true); 
    //wp_register_script('gg-easyzoom', get_template_directory_uri() . '/js/easyzoom.js', array('jquery'), OKTHEMES_THEMEVERSION, true); 
}

/**
 * Define image sizes - filter
 */

function gg_reverse_filter_single_catalog_wc_image_size( array $size = array() ){
    $size = array(
        'width'  => '9999',
        'height' => '9999',
        'crop'   => 1
    );
    return $size;
}

function gg_reverse_filter_thumbnail_wc_image_size( array $size = array() ){
    $size = array(
        'width'  => '70',
        'height' => '100',
        'crop'   => 1
    );
    return $size;
}

// single
add_filter( 'woocommerce_get_image_size_shop_single', 'gg_reverse_filter_single_catalog_wc_image_size' );
// catalog
add_filter( 'woocommerce_get_image_size_shop_catalog', 'gg_reverse_filter_single_catalog_wc_image_size' );
// thumbnail
add_filter( 'woocommerce_get_image_size_shop_thumbnail', 'gg_reverse_filter_thumbnail_wc_image_size' );

//Remove the filters at user input
if ( _get_field('gg_activate_product_image_sizes','option', false) === true ) {
    // single
    remove_filter( 'woocommerce_get_image_size_shop_single', 'gg_reverse_filter_single_catalog_wc_image_size' );
    // catalog
    remove_filter( 'woocommerce_get_image_size_shop_catalog', 'gg_reverse_filter_single_catalog_wc_image_size' );
    // thumbnail
    remove_filter( 'woocommerce_get_image_size_shop_thumbnail', 'gg_reverse_filter_thumbnail_wc_image_size' );
}


/**
 * WooCommerce Breadcrubs
 */
function gg_reverse_wc_breadcrumbs() {
    return array(
            'delimiter'   => ' <span class="delimiter">&frasl;</span> ',
            'wrap_before' => '<div class="gg-breadcrumbs"><i class="icon_house_alt"></i> ',
            'wrap_after'  => '</div>',
            'before'      => '',
            'after'       => '',
            'home'        => _x('Home', 'breadcrumb', 'reverse'),
        );
}
add_filter( 'woocommerce_breadcrumb_defaults', 'gg_reverse_wc_breadcrumbs' );

/**
 * Wishlist
 */

if ( class_exists( 'YITH_WCWL_Init' ) ) {
    //Set the option to shortcode
    update_option( 'yith_wcwl_button_position','shortcode' );
}

add_action( 'woocommerce_single_product_summary', 'gg_reverse_add_wishlist', 35 );
function gg_reverse_add_wishlist() {
    if ( class_exists( 'YITH_WCWL_Init' ) ) {
        echo do_shortcode( '[yith_wcwl_add_to_wishlist icon="fa fa-heart-o"]' );
    }
}



/**
 * Add Sold out badge
 */
include (PARENT_DIR.'/lib/woocommerce-sold-out.php');

/**
 * Add Products per page select
 */
if ( _get_field('gg_products_per_page_selector','option', true) === true ) {
    include (PARENT_DIR.'/lib/woocommerce-products-pp.php');
}

/**
 * Add View size guide button
 */
if ( class_exists( 'acf' ) ) {
    include (PARENT_DIR.'/lib/woocommerce-size-guide.php');
} //acf class end

/**
 * Hide shop page title
 */
add_filter('woocommerce_show_page_title', 'gg_reverse_remove_shop_title' );
function gg_reverse_remove_shop_title() {
    return false;
}

/** 
 * Remove tab headings
 */
add_filter('woocommerce_product_description_heading', 'gg_reverse_clear_tab_headings');
add_filter('woocommerce_product_additional_information_heading', 'gg_reverse_clear_tab_headings');
function gg_reverse_clear_tab_headings() {
    return '';
}

/** 
 * Remove product rating display on product loops
 */
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );

/** 
 * Remove product rating display on product single
 */
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );

/** 
 * Move product tabs 
 */
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_output_product_data_tabs', 60 );

/** 
 * Move product meta after single_product_summary  
 */
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
add_action( 'woocommerce_after_single_product_summary', 'woocommerce_template_single_meta', 2 );

/**
 * Add product share under product description in product page
 */
function gg_reverse_product_social_share_wrapper_begin() {
    echo '<div class="gg-product-meta-share">';
}
function gg_reverse_product_social_share_wrapper_end() {
    echo '</div>';
}
function gg_reverse_product_social_share() {
    get_template_part( 'parts/part', 'socialsharewc' );
}

add_action( 'woocommerce_after_single_product_summary', 'gg_reverse_product_social_share_wrapper_begin', 1 );
add_action( 'woocommerce_after_single_product_summary', 'gg_reverse_product_social_share', 3 );
add_action( 'woocommerce_after_single_product_summary', 'gg_reverse_product_social_share_wrapper_end', 4 );

//Move product sharing after single_product_summary 
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 40 );
add_action( 'woocommerce_after_single_product_summary', 'woocommerce_template_single_sharing', 8 );

/*
 * Add custom pagination
 */
function gg_reverse_wc_pagination() {
    gg_reverse_pagination();       
}
remove_action('woocommerce_after_shop_loop', 'woocommerce_pagination', 10);
add_action( 'woocommerce_after_shop_loop', 'gg_reverse_wc_pagination', 10);


/*
 * Add div wrapper around the ordering functions
 */
function gg_reverse_open_wc_ordering_wrapper(){
    echo '<div class="gg-wc-ordering-wrapper">';
}

function gg_reverse_close_wc_ordering_wrapper(){
    echo '</div>';
}

add_action( 'woocommerce_before_shop_loop', 'gg_reverse_open_wc_ordering_wrapper', 10);
add_action( 'woocommerce_before_shop_loop', 'gg_reverse_close_wc_ordering_wrapper', 40);

/*
 * Allow shortcodes in product excerpts
 */
if (!function_exists('woocommerce_template_single_excerpt')) {
   function woocommerce_template_single_excerpt( $post ) {
       global $post;
       if ($post->post_excerpt) echo '<div itemprop="description">' . do_shortcode(wpautop(wptexturize($post->post_excerpt))) . '</div>';
   }
}

/*
 * Shop page - Number of products per row
 */
add_filter('loop_shop_columns', 'gg_reverse_shop_columns');
if (!function_exists('gg_reverse_shop_columns')) {
    function gg_reverse_shop_columns() {
        return _get_field('gg_shop_product_columns','option', '3');
    }
}

/*
 * Shop page - Number of products per page
 */
add_filter('loop_shop_per_page',  'gg_reverse_shop_products_per_page', 20);
if (!function_exists('gg_reverse_shop_products_per_page')) {
    function gg_reverse_shop_products_per_page() {
        $product_per_page = _get_field('gg_product_per_page','option', '12');
        return $product_per_page;
    }
}


/**
 * Add search fragment
 */
function woocommerceframework_add_search_fragment ( $settings ) {
    $settings['add_fragment'] = '?post_type=product';
    return $settings;
}

/**
 * Enable/Disable Sale Flash
 */
if ( _get_field('gg_store_sale_flash','option', true) === true ) {
    remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10);
    add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10);
} else {
    remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10);
}

/**
 * Enable/Disable Products price
 */
if ( _get_field('gg_store_products_price','option', true) === true ) {
    remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);
    add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);    
} else {
    remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);
}

/**
 * Enable/Disable Add to cart
 */
if ( _get_field('gg_store_add_to_cart','option', true) === true ) {
    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
    add_action('woocommerce_after_shop_loop_item_title','woocommerce_template_loop_add_to_cart',30);
} else {
    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart',10);
}

/**
 * Options for product page
 */

/*Sale flash*/
if ( _get_field('gg_product_sale_flash','option', true) === false ) {
    remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10);
}

/*Price*/
if ( _get_field('gg_product_products_price','option', true) === false ) {
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10);
}

/*Product summary*/
if ( _get_field('gg_product_products_excerpt','option', true) === false ) {
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20);
}

/*Add to cart*/
if ( _get_field('gg_product_add_to_cart','option', true) === false ) {
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30);
}

/*Meta*/
if ( _get_field('gg_product_products_meta','option', true) === false ) {
    remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_template_single_sharing', 8 );
    remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_template_single_meta', 2 );
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 40 );
    remove_action( 'woocommerce_after_single_product_summary', 'gg_reverse_product_social_share_wrapper_begin', 1 );
    remove_action( 'woocommerce_after_single_product_summary', 'gg_reverse_product_social_share', 3 );
    remove_action( 'woocommerce_after_single_product_summary', 'gg_reverse_product_social_share_wrapper_end', 4 );
}

/*Size guide*/
if ( _get_field('gg_product_size_guide','option', true) === false ) {
    remove_action( 'woocommerce_single_product_summary', 'gg_size_guide', 35 );
}

/*Wishlist*/
if ( _get_field('gg_product_wishlist','option', true) === false ) {
    remove_action( 'woocommerce_single_product_summary', 'gg_reverse_add_wishlist', 35 );
}

/**
 * Enable/Disable Related products
 */
if ( _get_field('gg_product_related_products','option', true) === true ) {
    remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);
    add_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);
} else {
    remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);
}

/**
 * Enable/Disable Up Sells products
 */
if ( _get_field('gg_product_upsells_products','option', true) === true ) {
    remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
    add_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
} else {
    remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
}

/**
 * Enable/Disable Review tab
 */
if ( _get_field('gg_product_reviews_tab','option', true) === false ) {
add_filter( 'woocommerce_product_tabs', 'gg_reverse_product_remove_reviews_tab', 98);
    function gg_reverse_product_remove_reviews_tab($tabs) {
        unset($tabs['reviews']);
        return $tabs;
    }
}

/**
 * Enable/Disable Description tab
 */
if ( _get_field('gg_product_description_tab','option', true) === false ) {
add_filter( 'woocommerce_product_tabs', 'gg_reverse_product_remove_description_tab', 98);
    function gg_reverse_product_remove_description_tab($tabs) {
        unset($tabs['description']);
        return $tabs;
    }
}

/**
 * Enable/Disable Attributes tab
 */
if ( _get_field('gg_product_attributes_tab','option', true) === false ) {
add_filter( 'woocommerce_product_tabs', 'gg_reverse_product_remove_attributes_tab', 98);
    function gg_reverse_product_remove_attributes_tab($tabs) {
        unset($tabs['additional_information']);
        return $tabs;
    }
}


/**
 * Enable/Disable Cross Sells products
 */
if ( _get_field('gg_product_crosssells_products','option', true) === true ) {
    remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
    add_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_output',5 );

    if ( ! function_exists( 'woocommerce_cross_sell_output' ) ) {
        function woocommerce_cross_sell_output() {
            woocommerce_cross_sell_display( 1,1 ); // Display 3 products in rows of 3
        }
    }
} else {
    remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
}

/**
 * Catalog mode functions (must be always the last function)
 */
if ( _get_field('gg_store_catalog_mode','option', false ) === true ) {
    // Remove add to cart button from the product loop
    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart',10);
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
    remove_action('woocommerce_after_shop_loop_item_title','woocommerce_template_loop_add_to_cart',30);

    // Remove add to cart button from the product details page
    remove_action( 'woocommerce_before_add_to_cart_form', 'woocommerce_template_single_product_add_to_cart', 10, 2);
    
    add_filter( 'woocommerce_add_to_cart_validation', '__return_false', 10, 2 );

    // check for clear-cart get param to clear the cart
    add_action( 'init', 'gg_reverse_wc_clear_cart_url' );
    function gg_reverse_wc_clear_cart_url() {    
        global $woocommerce;
        if ( isset( $_GET['empty-cart'] ) ) { 
            $woocommerce->cart->empty_cart(); 
        }  
    }

    add_action( 'wp', 'gg_reverse_check_pages_redirect');
    function gg_reverse_check_pages_redirect() {
        $cart     = is_page( wc_get_page_id( 'cart' ) );
        $checkout = is_page( wc_get_page_id( 'checkout' ) );

        wp_reset_query();

        if ( $cart || $checkout ) {
            wp_redirect( esc_url( home_url( '/' ) ) );
            exit;
        }
    }
    
}


/**
 * Minicart function
 **/
if ( ! function_exists('gg_reverse_wc_minicart') ) { 
function gg_reverse_wc_minicart() {
ob_start();
?>
    <a class="dropdown-toggle" aria-haspopup="true" data-toggle="dropdown" href="<?php echo esc_url(wc_get_cart_url()); ?>" title="<?php esc_html_e('View your shopping cart', 'reverse'); ?>">
        <em class="visible-sm-inline"><?php esc_html_e('View shopping cart - ', 'reverse'); ?></em>
        <span><?php echo esc_html(WC()->cart->cart_contents_count); ?></span>
        <em class="visible-sm-inline"><?php esc_html_e('products', 'reverse'); ?></em>
    </a>

    <ul class="dropdown-menu noclose">

    <?php if (sizeof(WC()->cart->cart_contents) > 0) : ?>
        <li class="minicart-products-wrapper">
        <ul>

        <?php foreach (WC()->cart->cart_contents as $cart_item_key => $cart_item) :
            $_product = $cart_item['data'];
            if ($_product->exists() && $cart_item['quantity'] > 0 ) :
        ?>
                <li>
                <a href="<?php echo esc_url(get_permalink($cart_item['product_id']));?>">
                
                <?php            
                if (has_post_thumbnail($cart_item['product_id'])) {
                    $alt = get_post_meta($cart_item['product_id'], '_wp_attachment_image_alt', true);
                    $img_src = gg_reverse_aq_resize( get_post_thumbnail_id($cart_item['product_id']), 60, 90, true, true );
                    echo '<img src="'.esc_url($img_src).'" alt="'.$alt.'" />';
                }
                ?>
                
                <span class="product-title">
                    <?php echo apply_filters('woocommerce_cart_widget_product_title', $_product->get_title(), $_product); ?>
                </span>
                </a>
               
                <?php
                if($_product instanceof woocommerce_product_variation && is_array($cart_item['variation'])) :
                   echo woocommerce_get_formatted_variation( $cart_item['variation'] );
                endif;
                ?>
               
               <span class="quantity"><?php echo esc_html($cart_item['quantity']).' &times; '.apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key ); ?></span>
               </li>
           <?php endif; ?>
       <?php endforeach; ?>
       </ul>
       </li>
    <?php else: ?>
        <li class="empty"><?php esc_html_e('No products in the cart.', 'woocommerce'); ?></li>
    <?php endif; ?>


    <?php if (sizeof(WC()->cart->cart_contents) > 0 ) : ?>
    <li class="minicart-meta-wrapper">
        <ul class="minicart-btns">
            <li><a href="<?php echo esc_url(wc_get_cart_url()); ?>" class="minicart-btn"><?php esc_html_e('View cart', 'woocommerce'); ?></a></li>
            <li><a href="<?php echo esc_url(wc_get_checkout_url()); ?>" class="minicart-btn checkout"><?php esc_html_e('Checkout', 'woocommerce'); ?></a></li>
        </ul>

        <ul class="minicart-totals">
            <li>
            <span class="minicart-totals-title">
            <?php 
            if (get_option('js_prices_include_tax')=='yes') :
                esc_html_e('Total', 'woocommerce');
            else :
                esc_html_e('Subtotal', 'woocommerce');
            endif;
            ?>
            </span>
            <?php echo wc_price(WC()->cart->cart_contents_total + WC()->cart->tax_total); ?>
            </li>
        </ul>
    </li>
    <?php endif; ?>

    </ul>

    <?php return ob_get_clean(); ?>

<?php } 

}

add_filter( 'woocommerce_add_to_cart_fragments', 'gg_reverse_wc_minicart_fragment' );
if ( ! function_exists( 'gg_reverse_wc_minicart_fragment' ) ) {
    function gg_reverse_wc_minicart_fragment( $fragments ) {
        $fragments['.gg-woo-mini-cart'] = '<li class="menu-item gg-woo-mini-cart circle-menu-item dropdown">' . gg_reverse_wc_minicart() .'</li>';
        return $fragments;
    }
}

/**
 * Minicart function
 **/
if ( ! function_exists('gg_reverse_extras_menu') ) { 
    function gg_reverse_extras_menu() {
    ob_start();
    ?>
    <a href="#fullscreen-searchform" title="<?php esc_html_e('Search products', 'woocommerce'); ?>">
        <span><i class="fa fa-search"></i></span>
        <em class="visible-sm-inline"><?php esc_html_e('Search products', 'woocommerce'); ?></em>
    </a>

    <?php
    return ob_get_clean();
    } 
}

/**
 * WPML Multi currency function
 **/
if ( ! function_exists('gg_reverse_currency_switcher') ) { 
    function gg_reverse_currency_switcher() {
    ob_start();
    if ( class_exists('woocommerce_wpml') ) {
    ?>

    <a href="" data-toggle="dropdown" aria-haspopup="true" class="dropdown-toggle">
        <span><?php echo get_woocommerce_currency_symbol(); ?></span>
        <span class="hidden-sm hidden-xs hidden"><?php echo get_woocommerce_currency(); ?></span>
    </a>
    <?php do_action('currency_switcher'); ?>

    <?php
    }
    return ob_get_clean();
    } 
}

/**
 * WPML - Language dropdown with flags
 **/

if ( ! function_exists('gg_reverse_wpml_language_sel') ) {
    
    function gg_reverse_wpml_language_sel(){
        if (gg_reverse_is_wpml_activated()) {
            if (function_exists('icl_get_languages')) {
              $languages = icl_get_languages('skip_missing=0&orderby=custom&order=asc');
              if ($languages) {
                  $out = '';
                  $dropdown = '';
                  foreach ($languages as $lang) {
                      $lcode = explode('-',$lang['language_code']);
           
                      if ($lang['active']) {
                          $button = '<a href="#" data-toggle="dropdown" aria-haspopup="true" class="dropdown-toggle"><span>'.$lang['language_code'].'</span><span class="hidden-sm hidden-xs hidden">'.$lang['translated_name'].'</span></a>';
                      } else {
                          $dropdown .= '<li><a href="'.$lang['url'].'" title="'.$lang['native_name'].'"><img src="'.$lang['country_flag_url'].'" alt="'.$lang['translated_name'].'" />'.$lang['translated_name'].'</a></li>';
                      }
                  }
                  $out .= $button;
                  $out .= '<ul id="langswitch" class="dropdown-menu noclose">'.$dropdown.'</ul>';
                  return $out;
              }
            }
        }
    }
    
}


/**
 * Add Extras to Main menu
 */

add_filter( 'wp_nav_menu_items', 'gg_reverse_add_menu_items' , 10, 2 );
if ( ! function_exists( 'gg_reverse_add_menu_items' ) ) {
    function gg_reverse_add_menu_items( $items, $args ) {
        
        // Add to main menu only
        if ( 'main-menu' == $args->theme_location ) {

            if ( _get_field('gg_header_minicart','option', true) === true ) {
                // Add cart link to menu items
                $items .= '<li class="gg-woo-mini-cart circle-menu-item dropdown">' . gg_reverse_wc_minicart() .'</li>';
            }

            if ( _get_field('gg_header_search','option', true) === true ) {
                // Add search to menu items  
                $items .= '<li class="gg-menu-extras circle-menu-item">' . gg_reverse_extras_menu() .'</li>';
            }

            if ( gg_reverse_is_wpml_activated() ) {
                 // Add WPML language selector  
                $items .= '<li class="gg-language-switcher circle-menu-item dropdown">' . gg_reverse_wpml_language_sel() .'</li>';
            }
            
            if ( gg_reverse_is_wpml_activated() && class_exists('woocommerce_wpml') ) {
                // Add currency switcher to menu items  
                $items .= '<li class="gg-currency-switcher circle-menu-item dropdown">' . gg_reverse_currency_switcher() .'</li>';
            }

        }
        
        // Return menu items
        return $items;
    }
}

/* Add form control to input qty */
add_filter( 'woocommerce_quantity_input_classes', 'filter_function_name_4160', 10, 2 );
function filter_function_name_4160( $array, $product ){
    $array[] = 'form-control';

    return $array;
}