<?php
function register_gg_instagram_widget() {
	register_widget( 'gg_instagram_widget' );
}
add_action( 'widgets_init', 'register_gg_instagram_widget' );

class gg_instagram_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'gg-instagram-feed',
			esc_html__( 'Instagram', 'reverse' ),
			array( 'classname' => 'gg-instagram-feed', 'description' => esc_html__( 'Displays your latest Instagram photos', 'reverse' ) )
		);
	}

	function widget( $args, $instance ) {

		extract( $args, EXTR_SKIP );

		$title = empty( $instance['title'] ) ? '' : apply_filters( 'widget_title', $instance['title'] );
		$limit = empty( $instance['number'] ) ? 9 : $instance['number'];
		$followers = empty( $instance['followers'] ) ? '' : $instance['followers'];
		$link = empty( $instance['link'] ) ? '' : $instance['link'];

		echo wp_kses_post($before_widget);
		?>

		<?php
		$insta_username = '';
        if ( defined( 'SBIVER' ) ) {
            $insta = get_option('sb_instagram_settings');
            if ( isset($insta['sb_instagram_user_id']) ) {
                $insta_id = $insta['sb_instagram_user_id'];
            }
            if ( isset($insta['connected_accounts']) ) {
                $insta_username = $insta['connected_accounts'][$insta_id[0]]['username'];
            }            
        }
		?>

		<div class="media">
		<div class="media-left">
		<?php 
		if ( ! empty( $title ) ) { 
			echo wp_kses_post($before_title . $title . $after_title);
		}
		?>

		<?php
		if ( $followers != '' ) { ?>
		<p class="followers"><?php echo esc_html($followers); ?>
			<span><?php esc_html_e('Followers', 'reverse'); ?></span>
		</p>
		<?php } ?>

		<?php if ( $link != '' ) { ?>
		<a class="btn btn-default" href="//instagram.com/<?php echo esc_attr( trim( $insta_username ) ); ?>" rel="me"><?php echo esc_html($link); ?></a>
		<?php } ?>
		</div> <!-- .media-left -->

		<div class="media-body">
		<?php 
        //If Instagram Feed plugin is active, run shortcode
        if ( defined( 'SBIVER' ) ) {
            echo do_shortcode("[instagram-feed num=".$limit." imagepadding=15 cols=".$limit." hoverdisplay=likes showheader=false showbutton=false showfollow=false]");
        } else {
            printf( __('<a href="%s">Instagram Feed plugin</a> is not installed!','reverse'),
                esc_url( 'https://wordpress.org/plugins/instagram-feed/') );
        }
        ?>
		</div><!-- .media-body -->
		</div><!-- .media -->
		
		<?php
		echo wp_kses_post($after_widget);
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => esc_html__( 'Instagram', 'reverse' ), 'username' => '', 'followers' => '', 'link' => esc_html__( 'Follow Us', 'reverse' ), 'number' => 9 ) );
		$title     = esc_attr( $instance['title'] );
		$username  = esc_attr( $instance['username'] );
		$number    = absint( $instance['number'] );
		$followers = esc_attr( $instance['followers'] );
		$link      = esc_attr( $instance['link'] );
		?>
		<p><label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e( 'Title', 'reverse' ); ?>: <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_html($title); ?>" /></label></p>
		<p><label for="<?php echo esc_attr($this->get_field_id( 'number' )); ?>"><?php esc_html_e( 'Number of photos', 'reverse' ); ?>: <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr($this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo esc_html($number); ?>" /></label></p>
		<p><label for="<?php echo esc_attr($this->get_field_id( 'followers' )); ?>"><?php esc_html_e( 'Number of followers', 'reverse' ); ?>: <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'followers' ) ); ?>" name="<?php echo esc_attr($this->get_field_name( 'followers' ) ); ?>" type="text" value="<?php echo esc_html($followers); ?>" /></label></p>
		
		<p><label for="<?php echo esc_attr($this->get_field_id( 'link' )); ?>"><?php esc_html_e( 'Link text', 'reverse' ); ?>: <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'link' ) ); ?>" name="<?php echo esc_attr($this->get_field_name( 'link' ) ); ?>" type="text" value="<?php echo esc_attr($link); ?>" /></label></p>
		<?php

	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title']     = strip_tags( $new_instance['title'] );
		$instance['number']    = ! absint( $new_instance['number'] ) ? 9 : $new_instance['number'];
		$instance['followers'] = trim( strip_tags( $new_instance['followers'] ) );
		$instance['link']      = strip_tags( $new_instance['link'] );
		return $instance;
	}

}
