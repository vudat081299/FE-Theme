<?php
function gg_reverse_size_guide() {
    $size_guide                     = _get_field('gg_product_size_guide');
    $size_guide_name                = _get_field('gg_product_size_guide_name');
    $size_guide_style               = _get_field('gg_product_size_guide_style');
    $size_guide_style_page_link     = _get_field('gg_product_size_guide_style_page_link');
    $size_guide_style_external_link = _get_field('gg_product_size_guide_style_external_link');
    $size_guide_style_image         = _get_field('gg_product_size_guide_style_image');
    $size_guide_style_content       = _get_field('gg_product_size_guide_style_content');

    $class = $link_start = '';
    $link_end = '</a>';
    $icon = '<i class="fa fa-scissors"></i>';

    if ($size_guide) :
    

        switch ($size_guide_style) {
            case 'link_to_page':
                $link_start = '<a href="'.esc_url($size_guide_style_page_link).'">';
                break;
            case 'external_link':
                $link_start = '<a href="'.esc_url($size_guide_style_external_link).'">';
                break;
            case 'image':
                //Load scripts
                wp_enqueue_style('gg-magnific');
                wp_enqueue_script('gg-magnific');
                $class = 'has_magnific';
                $link_start = '<a class="lightbox-el" href="'.esc_url($size_guide_style_image).'">';
                break;
            case 'content':
                //Load scripts
                wp_enqueue_style('gg-magnific');
                wp_enqueue_script('gg-magnific');
                $class = 'has_magnific';
                $link_start = '<a class="lightbox-el gg-popup" data-effect="mfp-zoom-in" href="#gg-size-guide-popup">';
                break;
        }
    

    echo '<div class="size-guide-wrapper '.$class.'">';

    echo wp_kses_post( $link_start . $icon . $size_guide_name . $link_end );

    if ($size_guide_style == 'content') {
        echo '<div id="gg-size-guide-popup" class="white-popup mfp-with-anim mfp-hide">';
        echo wp_kses_post($size_guide_style_content);
        echo '</div>';
    }
    
    echo '</div>';

    endif;
}

//add the function after add to cart
add_action( 'woocommerce_single_product_summary', 'gg_reverse_size_guide', 35 );
?>