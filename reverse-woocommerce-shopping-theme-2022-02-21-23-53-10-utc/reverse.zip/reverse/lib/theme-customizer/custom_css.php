<?php
/*Custom CSS*/

//Font
$gg_headings_font = _get_field('gg_headings_font', 'option','Oswald');
$gg_body_font = _get_field('gg_body_font', 'option','Montserrat');

//Text color
$gg_text_body_color = _get_field('gg_text_body_color', 'option','#ababab'); //Default value: #ababab
$gg_headings_color = _get_field('gg_headings_color', 'option','#000000'); //Default value: #000000
$gg_link_color = _get_field('gg_link_color', 'option','#000000'); //Default value: #000000

//Primary color
$gg_primary_color = _get_field('gg_primary_color', 'option','#000000'); //Default value: #000000
?>

<?php if ( $gg_headings_font['font'] != 'Oswald' ) : ?>
	h1,	h2,	h3,	h4,	h5,	h6, .h1, .h2, .h3, .h4, .h5, .h6,
	.btn, label, .label, select, .form-control, .site-title,
	footer.site-footer .site-title, .navbar-nav > li > a,
	.gg-menu-extras li.minicart-products-wrapper ul > li > a > span.product-title,
	.gg-menu-extras li.minicart-meta-wrapper ul.minicart-btns li,
	.gg-menu-extras li.minicart-meta-wrapper ul.minicart-totals .amount,
	.gg-menu-extras li.empty, .dropdown-header,
	.navbar-nav > li.is-megamenu > .dropdown-menu > li > a,
	.dropdown-menu > li div.gg-extra-html ul.gg-slick-carousel .meta-wrapper a,
	footer.site-footer .gg-footer-info-box, .footer-social li, 
	.gg-widget.widget_tag_cloud li a, .gg-widget.contact, .vc_widget_contact_us,
	.gg-widget.working-hours span, .vc_widget_working_hours .widget.working-hours span,
	.gg-widget.social-icons ul li a, .gg-widget.gg-instagram-feed .followers,
	.vc_widget.vc_widget_instagram .followers, .page-links, footer.entry-meta a,
	.gg-contact-template .contact-details, .wpb-js-composer .vc_general.vc_btn3,
	.woocommerce .wc-proceed-to-checkout input[type="submit"],
	.woocommerce .product .summary .button,
	.woocommerce .place-order #place_order,
	.woocommerce .button.wc-forward,
	.woocommerce .shipping-calculator-form button.button,
	.gg-widget .tagcloud a,
	.gg-widget.widget_product_tag_cloud a,
	.woocommerce .shop_table.cart .product-meta-wrapper .product-name a,
	.woocommerce .cart-collaterals .coupon label,
	.woocommerce form.checkout #order_review .shop_table th.product-name,
	.woocommerce form.checkout #order_review .shop_table th.product-total,
	body.woocommerce-account .shop_table th,
	body.woocommerce-order-received .shop_table th.product-name,
	body.woocommerce-order-received .shop_table th.product-total,
	.gg-woo-mini-cart li.minicart-products-wrapper ul > li > a > span.product-title,
	.gg-woo-mini-cart li.minicart-meta-wrapper ul.minicart-btns li,
	.gg-woo-mini-cart li.minicart-meta-wrapper ul.minicart-totals .amount,
	.gg-woo-mini-cart li.empty,
	.woocommerce table.wishlist_table thead th,
	.woocommerce table.wishlist_table td.product-name {
	
		font-family: <?php echo esc_html($gg_headings_font['font']); ?>;

	}
<?php endif; ?>

<?php if ( $gg_body_font['font'] != 'Montserrat' ) : ?>
	body,
	input.form-control[type="text"],
	input.form-control[type="email"],
	textarea.form-control,
	input[type="radio"],
	input[type="checkbox"],
	.site-title small,
	.dropdown-menu > li > a span,
	.dropdown-menu > li > .dropdown-menu > li > a span,
	.gg-widget.gg-instagram-feed .followers span,
	.vc_widget.vc_widget_instagram .followers span,
	.woocommerce .cart .quantity input.minus,
	.woocommerce .cart .quantity input.plus,
	.woocommerce form.checkout ul.payment_methods li label,
	.woocommerce form.checkout #customer_details h3#ship-to-different-address label {

		font-family: <?php echo esc_html($gg_body_font['font']); ?>;
}
<?php endif; ?>


<?php if ($gg_text_body_color != '#ababab') { ?>
	body,
	input.form-control[type="text"],
	input.form-control[type="email"],
	textarea.form-control,
	input[type="radio"],
	input[type="checkbox"],
	.site-title small,
	.nav_crumb a,
	.dropdown-menu > li > a span,
	.dropdown-menu > li > .dropdown-menu > li > a span,
	.dropdown-menu > li > a:hover,
	.dropdown-menu > li > a:focus,
	.dropdown-menu > .active > a,
	.dropdown-menu > .active > a:hover,
	.dropdown-menu > .active > a:focus,
	.dropdown-menu > li > .dropdown-menu > li > a:hover,
	.dropdown-menu > li > .dropdown-menu > li > a:focus,
	.dropdown-menu > li > .dropdown-menu > .active > a,
	.dropdown-menu > li > .dropdown-menu > .active > a:hover,
	.dropdown-menu > li > .dropdown-menu > .active > a:focus,
	.navbar-default .navbar-nav .open > .dropdown-menu > .dropdown-submenu.open > a,
	.navbar-default .navbar-nav .open > .dropdown-menu > .dropdown-submenu.open > a:hover,
	.navbar-default .navbar-nav .open > .dropdown-menu > .dropdown-submenu.open > a:focus,
	.navbar-default .navbar-nav > .open > a,
	.navbar-default .navbar-nav > .open > a:hover,
	.navbar-default .navbar-nav > .open > a:focus,
	.dropdown-header,
	.navbar-nav > li.is-megamenu > .dropdown-menu > li.dropdown-submenu .dropdown-menu > li.dropdown-submenu .dropdown-menu > li > a,
	.navbar-nav > li.is-megamenu > .dropdown-menu > li > a,
	.gg-widget a,
	.gg_filter li a,
	.woocommerce .product .size-guide-wrapper a i,
	.woocommerce .product .summary .yith-wcwl-add-to-wishlist .add_to_wishlist i,
	.woocommerce.single-product .product  .product_meta a,
	.woocommerce.single-product .product  .product_meta .sku_wrapper .sku,
	.woocommerce-tabs .tabs li a,
	.gg-widget.widget_product_categories ul.product-categories li.cat-parent ul.children li > a,
	.woocommerce .cart-collaterals .cart_totals table a.shipping-calculator-button,
	body.woocommerce-checkout .woocommerce-info,
	body.woocommerce-account p.lost_password a,
	.woocommerce ul.products li .price,
	.woocommerce .el-grid.products div.product .price,
	.el-grid li.product .price,
	.woocommerce-MyAccount-navigation ul li a {
		color: <?php echo esc_html($gg_text_body_color); ?>;
	}
	.form-control::-moz-placeholder {
	 	color: <?php echo esc_html($gg_text_body_color); ?>;
	}
	.form-control::-webkit-input-placeholder {
	 	color: <?php echo esc_html($gg_text_body_color); ?>;
	}
<?php } ?>


<?php if ($gg_headings_color != '#000000') { ?>
	h1,
	h2,
	h3,
	h4,
	h5,
	h6,
	.h1,
	.h2,
	.h3,
	.h4,
	.h5,
	.h6,
	.site-title,
	.site-title a,
	article.page h2.entry-title,
	article.post h2.entry-title,
	article.post h1.entry-title,
	article.page h2.entry-title a,
	article.post h2.entry-title a,
	#comments .comment h4.media-heading,
	#comments .comment h4.media-heading a,
	.gg-contact-template .contact-details,
	.vc_toggle .vc_toggle_title,
	.vc_toggle .vc_toggle_title h4,
	.woocommerce .shop_table.cart td.actions .cart-collaterals .cart_totals th,
	.woocommerce .shop_table.cart td.actions .cart-collaterals .cart_totals td,
	.woocommerce form.checkout #order_review .shop_table th,
	.woocommerce form.checkout #order_review .shop_table td,
	body.woocommerce-account .shop_table th,
	body.woocommerce-order-received .shop_table th,
	body.woocommerce-order-received .shop_table td,
	.woocommerce table.wishlist_table thead th,
	.counter-holder p,
	#timeline label {
		color: <?php echo esc_html($gg_headings_color); ?>;
	}

	.woocommerce .product .upsells.products h2:after,
	.woocommerce .product .related.products h2:after,
	#reviews #comments h2:after,
	.gg-widget h4.widget-title:after,
	.gg_posts_grid .grid-title:after,
	.wpb_content_element .wpb_heading:after,
	.vc_widget .widgettitle:after,
	.wpb_heading.wpb_flickr_heading:after,
	.wpb_heading.wpb_contactform_heading:after,
	.wpb_content_element .widgettitle:after,
	.contact-form-mini-header:after {
		background-color: <?php echo esc_html($gg_headings_color); ?>;
	}

<?php } ?>

<?php if ($gg_link_color != '#000000') { ?>
	.pace, a, a:hover, a:focus, caption, label, .label, select option, legend, .btn-default, .btn-default:hover, .btn-default:focus, .btn-default.focus,
	footer.site-footer .btn-primary, .form-control, .input-group-addon, .has-success .form-control-feedback,
	i.form-control-feedback, .subheader-slider .tparrows, .subheader-slider .tparrows:before,
	.navbar-default .navbar-nav > li > a, 
	.gg-menu-extras li.minicart-meta-wrapper ul.minicart-totals .minicart-totals-title,
	.navbar-default .navbar-nav > .open > a,
	.navbar-default .navbar-nav > .open > a:hover,
	.navbar-default .navbar-nav > .open > a:focus,
	.navbar-default .navbar-nav > li > a:hover,
	.navbar-default .navbar-nav > li > a:focus,
	.navbar-default .navbar-nav > .active > a,
	.navbar-default .navbar-nav > .active > a:hover,
	.navbar-default .navbar-nav > .active > a:focus,
	.dropdown-menu > li > a,
	.dropdown-menu > li > .dropdown-menu > li > a,
	.dropdown-menu > li div.gg-extra-html ul.gg-slick-carousel .meta-wrapper a,
	.gg-widget a:hover,
	.gg-widget a:focus,
	.gg-widget.flickr-widget .flickr_stream_wrap a,
	.gg-widget.contact address,
	.vc_widget_contact_us .widget.contact address,
	.gg-widget.working-hours ul li:before,
	.vc_widget_working_hours .widget.working-hours ul li:before,
	.gg-widget.working-hours span,
	.vc_widget_working_hours .widget.working-hours span,
	.gg-widget.social-icons ul li a i,
	.wpb_content_element .widget.widget_recent_entries ul li a,
	.gg-widget.widget_recent_entries ul li a,
	.gg-widget.twitter-widget ul li a,
	.gg-widget.gg-instagram-feed .followers span,
	.vc_widget.vc_widget_instagram .followers span,
	.gg-widget.widget_rss a,
	.pagination-wrapper,
	.pagination > li.current > a,
	.pagination > li > a:hover,
	.pagination > li > span:hover,
	.pagination > li > a:focus,
	.pagination > li > span:focus,
	.page-links span:not(.page-links-title):hover,
	.pagination > li > a.next,
	.pagination > li > a.prev,
	.gg-gallery figure p,
	.counter-holder .counter,
	.counter-holder .vc_icon_element,
	.featured-icon-box .vc_icon_element .vc_icon_element-icon,
	.gg_list ul li:before,
	.gg_filter li.active a,
	.gg_filter li.active:hover a,
	.gg_filter li.active > a:focus,
	.gg_filter li:hover a,
	.gg_filter li a:hover,
	#fullscreen-searchform .btn,
	#fullscreen-searchform .close,
	p.demo_store,
	#reviews #comments .comment p.meta strong,
	#reviews #comments .comment .star-rating,
	.woocommerce form.woocommerce-ordering .bootstrap-select.open > .btn,
	footer.site-footer .woocommerce .button.wc-forward,
	.woocommerce .cart .quantity input.minus,
	.woocommerce .cart .quantity input.plus,
	.woocommerce.single-product .product  .product_meta,
	.woocommerce-tabs .tabs li.active a,
	.gg-widget.widget_product_categories ul.product-categories li > a:first-child,
	.gg-widget.widget_product_categories ul.product-categories li.current-cat a,
	.gg-widget.widget_product_categories ul.product-categories li.cat-parent ul.children li.current-cat > a,
	.gg-widget.widget_products a .product-title,
	.gg-widget.widget_recent_reviews li > a,
	.gg-widget.widget_top_rated_products a .product-title,
	.gg-widget.widget_recently_viewed_products a .product-title,
	.gg-widget.widget_shopping_cart li .quantity .amount,
	.gg-widget.widget_shopping_cart .total,
	.gg-widget.widget_shopping_cart li a,
	.gg-widget.widget_price_filter .price_slider_amount button,
	.woocommerce dl.variation dt,
	.woocommerce .cart-collaterals .cart_totals table,
	.woocommerce form.checkout ul.payment_methods li label,
	.woocommerce form.checkout #customer_details h3#ship-to-different-address label,
	body.woocommerce-order-received ul.order_details li strong,
	.gg-woo-mini-cart li.minicart-meta-wrapper ul.minicart-totals .minicart-totals-title,
	.woocommerce-message,
	.woocommerce-error,
	.woocommerce-info,
	.woocommerce #content table.wishlist_table.cart a.remove:hover,
	.woocommerce table.wishlist_table tr td.product-stock-status span.wishlist-in-stock,
	body .slick-prev:before, 
	body .slick-next:before,
	body .slick-prev, 
	body .slick-next,
	.woocommerce-MyAccount-navigation ul li.is-active a,
	.woocommerce-MyAccount-navigation ul li a:hover {
		color: <?php echo esc_html($gg_link_color); ?>;
	}

	.form-control:focus,
	.btn-default:hover, 
	.btn-default:focus, 
	.btn-default.focus, 
	.btn-default:active, 
	.btn-default.active, 
	.open > .dropdown-toggle.btn-default,
	.has-success .form-control,
	.has-success .form-control:focus,
	.navbar-nav > li.circle-menu-item > a > span,
	body .slick-dots li.slick-active button:before,
	.subheader-slider .tparrows:hover {
		border-color: <?php echo esc_html($gg_link_color); ?>;
	}

	.navbar-default.dark .navbar-nav > li.circle-menu-item > a > span {
		border-color: <?php echo gg_reverse_hex_shift(esc_html($gg_link_color),'darker', 20 ) ; ?>;
	}

	.btn-default-alt:hover, 
	.btn-default-alt:focus, 
	.btn-default-alt.focus, 
	.btn-default-alt:active, 
	.btn-default-alt.active, 
	.open > .dropdown-toggle.btn-default-alt {
	    border-color: <?php echo esc_html($gg_link_color); ?>;
	    color: <?php echo esc_html($gg_link_color); ?>;
	}

	.btn-primary,
	.btn-primary:hover,
	.nav-links a,
	.woocommerce .wc-proceed-to-checkout input[type="submit"],
	.woocommerce .product .summary .button,
	.woocommerce .place-order #place_order,
	.woocommerce .button.wc-forward,
	.woocommerce .shipping-calculator-form button.button,
	.navbar-nav > li.circle-menu-item > a:hover > span {
	    background-color: <?php echo esc_html($gg_link_color); ?>;
	    border-color: <?php echo esc_html($gg_link_color); ?>;
	}

	blockquote {
  		border-left-color: <?php echo esc_html($gg_link_color); ?>;
 	}

 	.navbar-nav > li > a:after,
 	.footer-social li > a:after,
 	#timeline .radio:checked + .line .circle,
 	.counter-holder em:before,
 	.wpb-js-composer .vc_toggle_default .vc_toggle_icon:before, 
	.wpb-js-composer .vc_toggle_default .vc_toggle_icon:after,
	.wpb-js-composer .vc_toggle_default .vc_toggle_icon,
	.wpb-js-composer .vc_tta-color-grey.vc_tta-style-classic .vc_tta-tab > a,
	.wpb-js-composer .vc_tta-color-grey.vc_tta-style-classic .vc_tta-tab.vc_active > a,
	.wpb-js-composer .vc_tta-color-grey.vc_tta-style-outline .vc_tta-tab.vc_active > a,
	.wpb-js-composer .vc_tta-color-grey.vc_tta-style-outline .vc_tta-tab > a,
	.gg-widget.widget_price_filter .ui-slider .ui-slider-handle {
	 	background-color: <?php echo esc_html($gg_link_color); ?>;
	}

<?php } ?>


<?php
/* Primary color */
if ($gg_primary_color != '#000000') :
?>	
	
	.navbar-default.dark {
		background: <?php echo esc_html($gg_primary_color); ?>;
  		border-color: <?php echo esc_html($gg_primary_color); ?>;
	}

	@media (max-width: 992px) {
		body.gg-slider-is-beneath_header .navbar-default:not(.navbar-fixed-top).dark {
			background: <?php echo esc_html($gg_primary_color); ?>;
	  		border-color: <?php echo esc_html($gg_primary_color); ?>;
		}
	}

	.navbar-default .navbar-nav > li.circle-menu-item.open > a > span,
	.navbar-default .navbar-nav > li.circle-menu-item.open > a:hover > span,
	.navbar-default .navbar-nav > li.circle-menu-item.open > a:focus > span {
		background: <?php echo gg_reverse_hex_shift(esc_html($gg_link_color),'darker', 20 ) ; ?>;
  		border-color: <?php echo gg_reverse_hex_shift(esc_html($gg_link_color),'darker', 20 ) ; ?>;
	}

	.navbar-default.dark .navbar-nav > li.circle-menu-item > a,
	footer.site-footer,
	.gg-gallery figure figcaption > i,
	.gg-gallery figure h2,
	.wpb-js-composer .vc_progress_bar .vc_single_bar .vc_bar,
	.featured-image-box figure.sadie,
	#fullscreen-searchform,
	span.soldout,
	.product-image-wrapper.inverse h3 span  {
		background: <?php echo esc_html($gg_primary_color); ?>;
	}

<?php endif; ?>