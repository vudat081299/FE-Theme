<header class="site-header default">

<?php get_template_part( 'lib/headers/part','default-menu' ); ?>

<?php gg_reverse_page_header(); ?>

</header>
<!-- End Header. Begin Template Content -->