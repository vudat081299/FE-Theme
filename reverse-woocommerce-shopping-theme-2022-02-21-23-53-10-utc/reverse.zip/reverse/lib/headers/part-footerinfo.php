<?php if( _get_field('gg_footer_info_box', 'option') ): ?>
<div class="gg-footer-info-box col-md-12">
    <ul class="nav nav-pills">

    <?php while( _has_sub_field('gg_footer_info_box', 'option') ): ?>

        <?php if (_get_sub_field('gg_footer_info_box_text')): ?>
        <li>
            <?php if (_get_sub_field('gg_footer_info_box_link')) { ?>
            <p><a href="<?php _the_sub_field('gg_footer_info_box_link'); ?>"><?php _the_sub_field('gg_footer_info_box_text'); ?></a></p>
            <?php } else { ?>
            <p><?php _the_sub_field('gg_footer_info_box_text'); ?></p>
            <?php } ?>
        </li>
        <?php endif; ?>

    <?php endwhile; ?>

    </ul>
</div><!-- .gg-footer-info-box-->
<?php endif; ?>