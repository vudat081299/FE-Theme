<?php
//Header styles
$overwrite_header_style = _get_field('gg_overwrite_header_style_on_page', gg_reverse_global_page_id(), false);

if ($overwrite_header_style) {
    $nav_style  = _get_field('gg_page_menu_design',gg_reverse_global_page_id(), 'light');
    $nav_width  = _get_field('gg_page_menu_width',gg_reverse_global_page_id(), 'fullwidth');
    $nav_sticky = _get_field('gg_page_sticky_menu',gg_reverse_global_page_id(), false);
} else {
    $nav_style  = _get_field('gg_menu_design','option', 'light');
    $nav_width  = _get_field('gg_menu_width','option', 'fullwidth');
    $nav_sticky = _get_field('gg_sticky_menu','option', false);
}


$nav_class = $nav_style;
$nav_class .= ($nav_width == 'fullwidth') ? ' gg-menu-is-fullwidth' : ' gg-menu-is-boxed'; 

?>

<?php echo ($nav_width == 'boxed') ? '<div class="container">' : ''; ?>
<nav class="navbar navbar-default <?php echo esc_attr($nav_class); ?>">
    <div class="container-fluid navbar-header-wrapper">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <div class="logo-wrapper">
                <?php get_template_part( 'lib/headers/part','logo' ); ?>
            </div><!-- .logo-wrapper -->

        </div><!-- .navbar-header -->

        <div class="navbar-collapse collapse" id="main-navbar-collapse">
            <!-- Begin Main Navigation -->
            <?php
            wp_nav_menu(
                array(
                    'theme_location'    => 'main-menu',
                    'container'         => '',
                    'container_class'   => '',
                    'menu_class'        => 'nav navbar-nav navbar-right',
                    'fallback_cb'       => 'gg_reverse_navwalker::fallback',
                    'menu_id'           => 'main-menu',
                    'walker'            => new gg_reverse_navwalker()
                )
            ); ?>
            <!-- End Main Navigation -->
        </div><!-- .navbar-collapse collapse -->
    </div><!-- .container -->
</nav><!-- nav -->
<?php echo ($nav_width == 'boxed') ? '</div>' : ''; ?>