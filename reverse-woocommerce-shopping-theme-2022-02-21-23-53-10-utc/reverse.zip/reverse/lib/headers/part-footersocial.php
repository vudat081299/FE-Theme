<?php
    $footer_social = _get_field('gg_footer_social','option',false);
?>

<?php if ($footer_social && _get_field('gg_social_icons','option') ) : ?>
<div class="footer-social">
    <div class="container-fluid">
        <div class="row">
            <ul class="nav nav-pills nav-justified">
                <?php
                    while (has_sub_field('gg_social_icons','option')) : //Loop through sidebar fields to generate custom sidebars

                        $s_name = get_sub_field('gg_social_icon_name','option');
                        $s_icon = get_sub_field('gg_select_social_icon','option');
                        $s_link = get_sub_field('gg_social_icon_link','option');

                        if (is_rtl()) {
                            echo '<li><a href="'.$s_link.'" target="_blank"><span class="hidden-xs">'.$s_name.'</span><i class="'.$s_icon.'"></i></a></li>';
                        } else {
                            echo '<li><a href="'.$s_link.'" target="_blank"><i class="'.$s_icon.'"></i><span class="hidden-xs">'.$s_name.'</span></a></li>';
                        }
                        
                    endwhile;
                ?>
            </ul>
        </div>
    </div>
</div>
<?php endif; ?>