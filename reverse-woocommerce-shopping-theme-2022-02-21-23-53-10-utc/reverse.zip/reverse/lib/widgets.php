<?php
//Include each file from the widgets directory
foreach (glob(PARENT_DIR.'/lib/widgets/'."*.php") as $filename) {
    include $filename;
}
?>