<?php
/**
 * WooCommerce
 * Description: Page template for WooCommerce
 *
 * @package WordPress
 * @subpackage reverse
 */
get_header(); ?>

<section id="content">
    <div class="container">
        <div class="row">
            <div class="<?php gg_reverse_page_container(); ?>">
                <?php woocommerce_content(); ?>
            </div><!-- /.gg_reverse_page_container() -->

            <?php gg_reverse_page_sidebar(); ?>

        </div><!-- .row -->
    </div><!-- .container -->    
</section>

<?php get_footer(); ?>