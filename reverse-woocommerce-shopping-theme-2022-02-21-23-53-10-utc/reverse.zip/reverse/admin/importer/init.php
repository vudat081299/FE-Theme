<?php

require_once(  dirname( __FILE__ ) .'/importer/okthemes-importer.php' ); //load admin theme data importer

class gg_reverse_OKThemes_Theme_Demo_Data_Importer extends gg_reverse_OKThemes_Theme_Importer {

    /**
     * Holds a copy of the object for easy reference.
     *
     * @since 2.2.0
     *
     * @var object
     */
    private static $instance;
    
    /**
     * Set the key to be used to store theme options
     *
     * @since 2.2.0
     *
     * @var object
     */
    public $theme_option_name         = 'my_theme_options'; //set theme options name here
    
    public $theme_options_file_name   = 'theme_options.txt';
    
    public $widgets_file_name         =  'widgets.json';
    
    public $content_demo_file_name    =  'content.xml';
	
	/**
	 * Holds a copy of the widget settings 
	 *
	 * @since 2.2.0
	 *
	 * @var object
	 */
	public $widget_import_results;
	
    /**
     * Constructor. Hooks all interactions to initialize the class.
     *
     * @since 2.2.0
     */
    public function __construct() {
    
		$this->demo_files_path = dirname(__FILE__) . '/demo-files/';

        self::$instance = $this;
		parent::__construct();

    }

	public function gg_reverse_set_demo_menus(){

		// Menus to Import and assign - you can remove or add as many as you want
        $main_menu   = get_term_by('name', 'Main', 'nav_menu');
        $footer_menu = get_term_by('name', 'Footer', 'nav_menu');

		set_theme_mod( 'nav_menu_locations', array(
                'main-menu'   => $main_menu->term_id,
                'footer-menu' => $footer_menu->term_id
            )
        );

	}

    public function gg_reverse_remove_hello_post(){

        //Remove the hello world post
        wp_delete_post(1);

        //Remove the samples pages
        wp_delete_post(2);
    }

    public function gg_reverse_set_page_options(){

        //Set the frontpage and the blog page
        $frontpage = get_page('701');
        $blogpage  = get_page('703');

        update_option('show_on_front', 'page');    // show on front a static page
        update_option('page_on_front', $frontpage->ID);
        update_option('page_for_posts', $blogpage->ID);

        //Set the WC pages
        if ( gg_reverse_is_wc_activated() ) {

            //Shop Page
            $shop_page = get_page_by_title('Shop');
            if($shop_page && $shop_page->ID){
                update_option('woocommerce_shop_page_id',$shop_page->ID);
            }
            
            //Cart Page
            $cart_page = get_page_by_title('Cart');
            if($cart_page && $cart_page->ID){
                update_option('woocommerce_cart_page_id',$cart_page->ID);
            }
            
            //Checkout Page
            $checkout_page = get_page_by_title('Checkout');
            if($checkout_page && $checkout_page->ID){
                update_option('woocommerce_checkout_page_id',$checkout_page->ID);
            }
            
            //My Account Page
            $myaccount_page = get_page_by_title('My Account');
            if($myaccount_page && $myaccount_page->ID){
                update_option('woocommerce_myaccount_page_id',$myaccount_page->ID);
            }

            //Set image sizes    
            $catalog   = array('width' => '9999','height' => '9999','crop' => 1);
            $single    = array('width' => '9999','height' => '9999','crop' => 1);
            $thumbnail = array('width' => '70','height' => '100','crop' => 1);
         
            // Image sizes
            update_option( 'shop_catalog_image_size', $catalog );   // Product category thumbs
            update_option( 'shop_single_image_size', $single );     // Single product image
            update_option( 'shop_thumbnail_image_size', $thumbnail );
        
        } else {
            echo 'WooCommerce is not installed.';
        }

    }

    public function gg_reverse_set_revslider_options(){

        //Set the revolution slider

        if( class_exists('RevSliderFront') ) {

            
            $slider_array = array(
                get_template_directory()."/admin/importer/demo-sliders/homepage_v1.zip",
                get_template_directory()."/admin/importer/demo-sliders/homepage_v2.zip",
                get_template_directory()."/admin/importer/demo-sliders/homepage_v3.zip",
                get_template_directory()."/admin/importer/demo-sliders/homepage_v4.zip",
                get_template_directory()."/admin/importer/demo-sliders/homepage_v5.zip"
            );


            $slider = new RevSlider();
             
            foreach($slider_array as $filepath){
                $slider->importSliderFromPost(true,true,$filepath); 
            }
             
            echo ' Slider processed';
            
        } else {
            echo '<p>Revolution Slider is not installed. The corresponding settings were not applied.</p>';
        }
    }    


}

new gg_reverse_OKThemes_Theme_Demo_Data_Importer;