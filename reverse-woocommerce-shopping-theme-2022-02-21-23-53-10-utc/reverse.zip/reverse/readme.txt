Theme Installation

------------------
-----------------------------
Extract the files from the dezert-package.zip



Inside the extracts of the packed folder you'll find the dezert.zip file. You can upload it to your wordpress theme folder via WP-Admin.

Please follow

 http://codex.wordpress.org/Using_Themes#Adding_New_Themes

-----------------------------------------------

Thank you for your purchase!