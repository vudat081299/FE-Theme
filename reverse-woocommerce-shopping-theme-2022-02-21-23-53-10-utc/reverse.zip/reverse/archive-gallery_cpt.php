<?php
/**
 * The template for displaying Gallery archives
 *
 * @package WordPress
 * @subpackage reverse
 */
get_header(); ?>

<?php
wp_enqueue_style( 'gg-isotope' );
wp_enqueue_script( 'gg-isotope' );
?>

<section id="content">
    <div class="container">
        <div class="row">
            <div class="<?php gg_reverse_page_container(); ?>">

            <?php if (have_posts()) :
            // Queue the first post.
            the_post();
            // Rewind the loop back
            rewind_posts();
            ?>
            <div class="gg_posts_grid">
                <ul class="el-grid gg-gallery" data-layout-mode="fitRows" data-gap="gap">
                <?php while (have_posts()) : the_post(); ?>
                    <li class="isotope-item col-xs-6 col-md-3">
                        <?php get_template_part( 'parts/gallery/part','gallery-post' ); ?>
                    </li>
                <?php endwhile; ?>
                </ul>
            </div>

            <?php if (function_exists("gg_reverse_pagination")) {
                gg_reverse_pagination();
            } ?>

            <?php // If no content, include the "No posts found" template.
            else :
                get_template_part( 'parts/post-formats/part', 'none' );
            endif;
            ?>

            </div>
            <?php gg_reverse_page_sidebar(); ?>

        </div><!-- .row -->
    </div><!-- .container -->    
</section>

<?php get_footer(); ?>