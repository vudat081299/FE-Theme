<?php
/**
 * Footer
 *
 * @package WordPress
 * @subpackage reverse
 */
?>
    <?php get_template_part( 'lib/headers/part','footersocial' ); ?>
    
    <footer class="site-footer">

        <div class="container">
            <div class="row">

            <?php get_template_part( 'lib/headers/part','footerlogo' ); ?>

            <?php get_template_part( 'lib/headers/part','footerinfo' ); ?>

            <?php if( _get_field('gg_footer_widgets', 'option', false) ) : ?>
            <div class="footer-widgets col-md-12">
                <?php get_sidebar("footer"); ?>
            </div>
            <?php endif; ?>

            <!-- Begin Footer Navigation -->
            <?php
            wp_nav_menu(
                array(
                    'theme_location'    => 'footer-menu',
                    'container_class'   => 'gg-footer-menu col-md-12',
                    'menu_class'        => 'nav navbar-nav',
                    'menu_id'           => 'footer-menu',
                    'fallback_cb'       => false,
                    'depth'             => -1
                )
            ); ?>
            <!-- End Footer Navigation -->

            <?php if( _get_field('gg_footer_extras', 'option', true) ) : ?>
            <div class="footer-extras col-md-12">
                <?php if ( _get_field('gg_footer_extras_copyright', 'option', true) != '') : ?>
                    <p><?php echo esc_html( _get_field('gg_footer_extras_copyright', 'option', '&copy; 2015 Reverse') ); ?></p>
                <?php endif; ?>
            </div><!-- /footer-extras -->
            <?php endif; ?>

            </div><!-- .row -->
        </div><!-- /.container -->
    </footer>

    <!-- Site border -->
    <div id="gg-site-border-left"></div>
    <div id="gg-site-border-right"></div>
    <div id="gg-site-border-top"></div>
    <div id="gg-site-border-bottom"></div>
    <!-- End site border -->


    <?php if (_get_field('gg_script', 'option') != '') { ?>
        <script type="text/javascript">
                <?php echo stripslashes(_get_field('gg_script', 'option')); ?>
        </script>
    <?php } ?>

    <?php wp_footer(); ?>
    </body>
</html>